package org.bitvise;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.VpnService;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.ParcelFileDescriptor;
import android.os.PowerManager;
import android.system.OsConstants;
import android.text.TextUtils;
import com.trilead.ssh2.Connection;
import com.trilead.ssh2.ConnectionMonitor;
import com.trilead.ssh2.DynamicPortForwarder;
import com.trilead.ssh2.HTTPProxyData;
import com.trilead.ssh2.InteractiveCallback;
import com.trilead.ssh2.KnownHosts;
import com.trilead.ssh2.LocalPortForwarder;
import com.trilead.ssh2.ServerHostKeyVerifier;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import kpn.soft.dev.kpnrevolution.natives.Tun2Socks;
import net.agn.vpn.R;
import net.agn.vpn.InjectorService;
import net.agn.vpn.LogItem;
import net.agn.vpn.MainActivity;
import net.agn.vpn.TcodesApplication;
import net.agn.vpn.core.CIDRIP;
import net.agn.vpn.core.NetworkSpace;
import net.agn.vpn.core.Pinger;
import net.agn.vpn.logger.VPNLog;
import net.agn.vpn.model.IProtect;
import net.agn.vpn.util.Constants;
import net.agn.vpn.util.CustomNativeLoader;
import net.agn.vpn.util.KillThis;
import net.agn.vpn.util.Util;

public class SSHTunnelService extends VpnService implements   ServerHostKeyVerifier,
        InteractiveCallback,  ConnectionMonitor, Handler.Callback, IProtect.c
{

    private Pinger n;

    @Override
    public boolean a(Socket socket)
    {
        return protect(socket);
    }

    @Override
    public void b()
    {
        onDisconnect();
        stopSelf();
    }

    private Notification.Builder notification;
    private NotificationManager notificationManager;
    private Context context;

    private static final String TAG = "SSHTunnel";
    private static final int MSG_CONNECT_START = 0;
    private static final int MSG_CONNECT_FINISH = 1;
    private static final int MSG_CONNECT_SUCCESS = 2;
    private static final int MSG_CONNECT_FAIL = 3;
    private static final int MSG_DISCONNECT_FINISH = 4;
    //public static final String SSL_SNI = "SNI_HOST";
    public static final String START_SSH = "START_SSH_SERVICE";
    private static final String AUTH_PASSWORD = "password";
    private SharedPreferences settings = null;
    private DynamicPortForwarder dpf = null;
    public volatile static boolean isConnecting = false;
    public volatile static boolean isStopping = false;
    public static String SSL_HOST = "SSL_HOST";
    public static final String STOP_SSH = "STOP_SSH";
    public static final String SSL_PORT = "SSL_PORT";
    public static final String LOCAL_PORT = "LOCAL_PORT";
    public static final String USERNAME = "USERNAME";
    public static final String PASSWORD = "PASSWORD";
    private final static int RECONNECT_TRIES = 2;
    private Connection connection;
    public static volatile boolean connected = false;
    private String mHost;
    private String mUsername;
    private String mPassword;
    private int mLocalPort;
    private boolean isAlive = false;
    private boolean isAuthFailed = false;
    private ArrayDeque<LogItem> log_history = new ArrayDeque<LogItem>();
    private LogListener listener;
    private OnConnectionChangeListener occl;
    private Thread sshThread;
    private int mPort;
    private LocalPortForwarder local_port;
    private PowerManager.WakeLock wakeLock;
    private Thread mVpnThread;
    private String privateIpAddress;
    private java.lang.Process pdnsdProcess;
    public static boolean isRunning = false;
    public String FLAG_VPN_START = "START";
    public String FLAG_VPN_STOP = "STOP";
    public static final String LOCAL_SERVER_ADDRESS = "127.0.0.1";
    public static final String LOCAL_SERVER_PORT = "1080";
    private String mRouter;
    private int mMtu = 1500;
    private ParcelFileDescriptor tunFd;
    private Thread tun2socksThread = null;
    private NetworkSpace mRoutes;
    private Constants conts;

    private Process dnsProcess;
    private File filedns;
    private static final String DNS_BIN = "libstartdns";
    private final static String PDNSD_BIN = "libpdnsd";



    public class NotifMsg
    {
        public int state;
    }

    public interface LogListener
    {
        void log(LogItem item);
        void updateState(int state);

    }

    public interface OnConnectionChangeListener
    {
        void onChanged(boolean z);
    }

    public void setLogListener(LogListener LogListener)
    {
        listener = LogListener;
    }

    public void setOnConnectionChangeListener(OnConnectionChangeListener OnConnectionChangeListener)
    {
        occl = OnConnectionChangeListener;
    }

    private static WeakReference<SSHTunnelService> sRunningInstance = null;

    public final static boolean isServiceStarted()
    {
        final boolean isServiceStarted;
        if (sRunningInstance == null)
        {
            isServiceStarted = false;
        }
        else if (sRunningInstance.get() == null)
        {
            isServiceStarted = false;
            sRunningInstance = null;
        }
        else
        {
            isServiceStarted = true;
        }
        return isServiceStarted;
    }

    private void markServiceStarted()
    {
        sRunningInstance = new WeakReference<SSHTunnelService>(this);
    }

    private void markServiceStopped()
    {
        sRunningInstance = null;
    }

    private void setWakelock()
    {
        try
        {

            this.wakeLock = ((PowerManager) getSystemService(Context.POWER_SERVICE)).newWakeLock(1, "SocksIP::Tag");
            this.wakeLock.acquire();
        }
        catch (Exception e)
        {
            //Log.d("WAKELOCK", e.getMessage());
        }
    }

    private void unsetWakelock()
    {
        if (this.wakeLock != null && this.wakeLock.isHeld())
        {
            // Log.e("WAKELOCK", "is disabled");
            this.wakeLock.release();
        }
    }
    // Flag indicating if this is an ARMv6 device (-1: unknown, 0: no, 1: yes)
    private String reason = null;

    private Handler handler;
    private Handler m_Handler=new Handler();

    public interface StatusChangeListener
    {
        public void onStatusChanged(int status);
        public void onLogReceived(String logString);
    }

    private static ConcurrentHashMap<StatusChangeListener, Object> m_OnStatusChangedListeners=new ConcurrentHashMap<StatusChangeListener, Object>();

    public static void addOnStatusChangedListener(StatusChangeListener listener)
    {
        if (!m_OnStatusChangedListeners.containsKey(listener))
        {
            m_OnStatusChangedListeners.put(listener, 1);
        }
    }

    public static void removeOnStatusChangedListener(StatusChangeListener listener)
    {
        if (m_OnStatusChangedListeners.containsKey(listener))
        {
            m_OnStatusChangedListeners.remove(listener);
        }
    }

    private void onStatusChanged(final int status)
    {
        m_Handler.post(new Runnable() {
            @Override
            public void run()



            {
                for (Map.Entry<StatusChangeListener, Object> entry : m_OnStatusChangedListeners.entrySet())
                {
                    entry.getKey().onStatusChanged(status);
                }
            }
        });
    }

    public void writeLog(final String logs)
    {
        m_Handler.post(new Runnable() {
            @Override
            public void run()
            {
                for (Map.Entry<StatusChangeListener, Object> entry : m_OnStatusChangedListeners.entrySet())
                {
                    entry.getKey().onLogReceived(logs);
                }
            }
        });
    }

    private final BroadcastReceiver o = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent)
        {
            String action = intent.getAction();
            if (action != null && action.equals("ACTION__SSH_TUNNEL"))
            {

            }
        }
    };


    private void authenticate()
    {
        try
        {
            if (connection.authenticateWithNone(mUsername))
            {
                log("'None' authentication");
                return;
            }
        }
        catch (Exception e)
        {
            log("Host does not support 'none' authentication.");
        }
        try
        {
            if (this.connection.isAuthMethodAvailable(this.mUsername, AUTH_PASSWORD))
            {
                //log("Password auth available");
                log(R.string.state_auth);
                if (this.connection.authenticateWithPassword(this.mUsername, this.mPassword))
                {
                    log("authenticating with password");
                    return;
                }
                log("authentication failed");
                isAuthFailed = true;
                onStatusChanged(1);
            }
        }
        catch (Exception e)
        {
            //log(e.getMessage());
        }
    }

    public boolean connect()
    {


        try
        {
            log("Waiting for server reply");
            connection = new Connection(mHost, mPort);
            if (!conts.isDirect())
            {
                HTTPProxyData data = new HTTPProxyData("127.0.0.1", mLocalPort);
                connection.setProxyData(data);
            }
            connection.setCompression(true);
            connection.addConnectionMonitor(this);
            //log(R.string.state_connecting);
            onStatusChanged(0);
            connection.connect(this, 6 * 1000, 60 * 1000);
            connected = true;
            try
            {
                // enter a loop to keep trying until authentication
                int i = 0;
                while (this.connected && !this.connection.isAuthenticationComplete())
                {
                    try
                    {
                        int i2 = i + 1;
                        if (i >= 1)
                        {
                            break;
                        }
                        authenticate();
                        Thread.sleep((long) 1000);
                        i = i2;
                    }
                    catch (Exception e)
                    {
                        return false;
                    }
                }
            }
            catch (Exception e)
            {
                log("Thread issue on SSH connection during authentication");
                return false;
            }
            try
            {
                if (connection.isAuthenticationComplete())
                {

                    return enablePortForward();
                }

            }
            catch (Exception e)
            {
                log("Problem with SSH on server port");
                return false;
            }

            return false;
        }
        catch (Exception e)
        {
            //log("SSH Error: " + e.getMessage());
            log("SSH connection problem");
            return false;
        }
    }

    public static void a(Context c)
    {
        new Connection.Core(c).execute();
    }

    @Override
    public void connectionLost(Throwable th)
    {
        log("<b>Connection lost</b>");
        //log(new StringBuffer().append("SSH: ").append(th.getMessage()).toString());
        //Tun2Socks.Stop();
        if (!isConnecting && !isStopping)
        {
            if (!isOnline())
            {
                stopReconnect();
            }
            else if (th == null)
            {
                stopReconnect();
            }
            else if (th.getMessage().contains("There was a problem during connect"))
            {
                //log("connection lost" + th);
            }
            else if (th.getMessage().contains("Closed due to user request"))
            {
                //log("connection lost" + th);
            }
            else if (th.getMessage().contains("The connect timeout expired"))
            {
                reconnect();
            }
            else if (!th.getMessage().contains("socket closed"))
            {
                log(new StringBuffer().append("connection lost: ").append(th.getMessage()).toString());

                //Log.e(TAG, new StringBuffer().append("connection lost: ").append(th.getMessage()).toString());
                //stopReconnect2();
                reconnect();
            }
        }
    }

     private void reconnect()
    {
        if (this.connected && InjectorService.isRunning)
        {
            int i = 10;
            while (InjectorService.isRunning)
            {
				IProtect.a();
                onDisconnect();
				
                log(R.string.state_reconnecting);
                //log("<b>Reconnecting...</b>");
                //startService(new Intent(this, InjectorService.class).setAction(InjectorService.ACTION_RESTART));
                if (connect())
                {
                    //log("<b>Connected</b>");
                    //onStatusChanged(3);
                    log(R.string.state_connected);
                    // Connection and forward successful
                    handler.sendEmptyMessage(MSG_CONNECT_FINISH);
                    handler.sendEmptyMessage(MSG_CONNECT_SUCCESS);
                    vpn_handler(true);
                    return;
                }
                try
                {
                    Thread.sleep((long) 100);
                }
                catch (Exception e)
                {
                }
                i++;
            }
            return;
        }
        stopReconnect();
    }


    public void stopReconnect()
    {
        //startService(new Intent(this, InjectorService.class).setAction(InjectorService.ACTION_STOP));
        connected = false;
        stopForeground(true);
        log("Reconnect stopped");
        stopSelf();



        return;
    }


    public boolean enablePortForward()
    {
        try
        {
            local_port = connection.createLocalPortForwarder(8053, "clients3.google.com", 80);
            dpf = connection.createDynamicPortForwarder(new InetSocketAddress("127.0.0.1", 1080));
            if (this.n != null)
            {
                this.n.close();
                this.n = null;
            }
            this.n = new Pinger(connection, "clients3.google.com");
            this.n.start();

            log("Forward Success");
            return true;
        }
        catch (Exception e)
        {
            log("SSH: " + e.getMessage());
            log("Could not create local port forward");
            return false;
        }
    }


    public boolean isOnline()
    {

        ConnectivityManager manager = (ConnectivityManager) this.getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if (networkInfo == null)
        {
            if (reason == null)
                reason = getString(R.string.fail_to_online);
            return false;
        }
        return true;
    }

    @Override
    public void onRevoke()
    {
        super.onRevoke();
        IProtect.b();
    }


    @Override
    public IBinder onBind(Intent intent)
    {
        return new MyBinder();
    }

    public class MyBinder extends Binder
    {
        public SSHTunnelService getService()
        {
            return SSHTunnelService.this;
        }
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        IProtect.c = this;
        Locale.setDefault(new Locale("en"));
        mRoutes = new NetworkSpace();
        handler = new Handler(this);
        settings = TcodesApplication.getSharedPreferences();
        conts = new Constants(this);
    }

    /** Called when the activity is closed. */

    public void onDisconnect()
    {
        try
        {
            markServiceStopped();
        }
        catch (Exception e)
        {
            //log(e.getMessage());
        }

        new Thread(new Runnable() {
            @Override
            public void run()
            {
                connected = false;
                try
                {
                    if (local_port != null)
                    {
                        local_port.close();
                        local_port = null;
                    }
                }
                catch (Exception ignore)
                {

                }
                try
                {
                    if (dpf != null)
                    {
                        dpf.close();
                        dpf = null;
                    }
                }
                catch (Exception ignore)
                {
                    // Nothing
                }
                if (n != null)
                {
                    n.close();
                    n = null;
                }
                if (connection != null)
                {
                    connection.close();
                    connection = null;
                }
                try
                {
                    if (sshThread != null)
                    {
                        sshThread.stop();
                    }
                }
                catch (Exception e)
                {

                }
            }
        }).start();
        log(R.string.state_disconnected);
        if (!isAuthFailed)
        {
            onStatusChanged(2);
        }

        vpn_handler(false);
    }

    // This is the old onStart method that will be called on the pre-2.0
    // platform. On 2.0 or later we override onStartCommand() so this
    // method will not be called.
    @SuppressLint("WrongConstant")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId)
    {



        String action = intent.getAction();

        if (action.equals(START_SSH))
        {


            log("Building configuration...");
            mHost = conts.getSSHHost();
            if (conts.isCustom())
            {
                if (conts.getTunMode() == 0)
                {
                    mPort = conts.getSSHDropbear();
                }
                else if (conts.getTunMode() == 1)
                {
                    mPort = conts.getSSLPort();
                }
                else
                {
                    mPort = conts.getSSHPort();
                }
            }
            else
            {
                if (conts.isSSL())
                {
                    mPort = conts.getSSLPort();
                }
                else if (conts.isDirectP())
                {
                    mPort = conts.getSSHDropbear();
                }
                else
                {
                    mPort = conts.getSSHPort();
                }
            }
            mUsername = conts.getUsername();
            mPassword = conts.getPassword();
            mLocalPort = conts.getLocalPort();
            isAuthFailed = false;
            log("Starting VPN tunneling");
            sshThread = new Thread(new Runnable() {
                @Override
                public void run()
                {
                    log(R.string.state_connecting);
                    handler.sendEmptyMessage(MSG_CONNECT_START);
                    if (connect())
                    {
                        //log("<b>Connected</b>");
                        log(R.string.state_connected);

                        // Connection and forward successful
                        handler.sendEmptyMessage(MSG_CONNECT_FINISH);
                        handler.sendEmptyMessage(MSG_CONNECT_SUCCESS);
                        vpn_handler(true);

                    }
                    else
                    {
                        // Connection or forward unsuccessful
                        //log("<b>Disconnected</b>");
                        log(R.string.state_disconnected);
                        handler.sendEmptyMessage(MSG_CONNECT_FINISH);
                        handler.sendEmptyMessage(MSG_CONNECT_FAIL);
                        try
                        {
                            Thread.sleep(50);
                        }
                        catch (InterruptedException ignore)
                        {
                            // Nothing
                        }
                        connected = false;
                        stopSelf();
                    }

                    isConnecting = false;
                }
            });
            sshThread.start();
            markServiceStarted();
        }
        else if (action.equals(STOP_SSH))
        {
            onDisconnect();
            stopdns();
        }
        else if (action.equals("RECONNECT"))
        {
            new Thread(new Runnable() {
                @Override
                public void run()
                {
                    reconnect();
                }
            }).start();
        }
        return 1;

    }

    // XXX: Is it right?
    @Override
    public String[] replyToChallenge(String name, String instruction,
                                     int numPrompts, String[] prompt, boolean[] echo) throws Exception
    {
        String[] responses = new String[numPrompts];
        for (int i = 0; i < numPrompts; i++)
        {
            // request response from user for each prompt
            if (prompt[i].toLowerCase().contains("password"))
                responses[i] = mPassword;
        }
        return responses;
    }



    @Override
    public boolean verifyServerHostKey(String hostname, int port, String serverHostKeyAlgorithm, byte[] serverHostKey) throws Exception
    {
        try
        {
            String fingerPrint = KnownHosts.createHexFingerprint(serverHostKeyAlgorithm, serverHostKey);
            log("Server Hostkey: " + fingerPrint);
            log("Hostkey algorithm: " + serverHostKeyAlgorithm);
            return true;
        }
        catch (Exception e)
        {
            //log("SSH: " + e.getMessage());
        }
        return false;

    }

    private void stopdns()
    {

        //SharedPreferences.Editor editor = this.getSharedPreferences("pref", MODE_PRIVATE).edit();
        //editor.putString("a", "noreconnect");
        //editor.commit();

        filedns = CustomNativeLoader.loadNativeBinary(this, DNS_BIN, new File(this.getFilesDir(), DNS_BIN));

        if (filedns != null)
//dnsProcess.destroy();
            try
            {
                if (filedns != null)
                    KillThis.killProcess(filedns);
            }
            catch (Exception e)
            {}

        dnsProcess = null;
        filedns = null;

    }



    public void log(String msg)
    {
        VPNLog.logInfo(msg);
		/*LogItem item = new LogItem();
         item.log = msg;
         handler.sendMessage(handler.obtainMessage(9, item));*/
    }

    private void log(int state)
    {
        NotifMsg msg = new NotifMsg();
        msg.state = state;
        VPNLog.logInfo(getString(state));
        handler.sendMessage(handler.obtainMessage(10, msg));
    }

    @Override
    public boolean handleMessage(Message msg)
    {
        Editor ed = settings.edit();
        switch (msg.what)
        {
            case MSG_CONNECT_START:
                occl.onChanged(true);
                ed.putBoolean("isConnecting", true);
                break;
            case MSG_CONNECT_FINISH:
                ed.putBoolean("isConnecting", false);
                ed.putBoolean("isSwitching", false);
                break;
            case MSG_CONNECT_SUCCESS:
                occl.onChanged(true);
                ed.putBoolean("isRunning", true);
                // stateChanged = new ConnectivityBroadcastReceiver();
                // registerReceiver(stateChanged, new IntentFilter(
                // ConnectivityManager.CONNECTIVITY_ACTION));
                break;
            case MSG_CONNECT_FAIL:
                occl.onChanged(false);
                ed.putBoolean("isRunning", false);
                break;
            case MSG_DISCONNECT_FINISH:
                occl.onChanged(false);
                ed.putBoolean("isRunning", false);
                ed.putBoolean("isSwitching", false);
                // for widget, maybe exception here

                break;
            case 9:
                LogItem item = (LogItem)msg.obj;
                listener.log(item);
                log_history.addLast(item);
                if (log_history.size() == 500)
                {
                    log_history.clear();
                }
                break;
            case 10:
                NotifMsg notifMsg = (NotifMsg)msg.obj;
                updateNotification(notifMsg.state);
                switch (notifMsg.state)
                {
                    case R.string.state_connecting:
                    case R.string.state_reconnecting:
                    case R.string.state_auth:
                    case R.string.state_connected:

                        isAlive = true;
                        break;
                    case R.string.state_disconnected:
                        isAlive = false;
                }
                listener.updateState(notifMsg.state);
                break;
        }

        ed.commit();
        return true;
    }

    public ArrayDeque<LogItem> getLogHistory()
    {
        return this.log_history;
    }

    public boolean isActive()
    {
        return this.isAlive;
    }

    @SuppressLint("WrongConstant")
    private void updateNotification(int state)
    {

        if (settings.getBoolean("som_notify", true))
        {
            if (state == R.string.state_disconnected)
            {
                stopForeground(true);
                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
                r.play();
            }
            else
            {
                notificationManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

                this.notification = new Notification.Builder(this);

                notification = new Notification.Builder(this);
                notification.setColor(Color.rgb(244, 67, 54));
                String title = settings.getBoolean("custom_tweak", false) ? "Custom" : settings.getString("TweakName", "");
                notification.setContentTitle(getString(R.string.app_name) + " - " + settings.getString("SSHName", "") + " using " + title);
                notification.setContentText(getString(state));

                if (Build.VERSION.SDK_INT >= 23)
                {
                    notification.setSmallIcon(getIcon(state));
                    notification.setColor(Color.TRANSPARENT);
                }
                else
                {
                    notification.setSmallIcon(getIcon(state));
                }
                notification.setSound(RingtoneManager.getDefaultUri(2));
                this.notification.setOnlyAlertOnce(true);
                this.notification.setOngoing(true);
                notification.setUsesChronometer(true);
                this.notification.setPriority(Integer.MAX_VALUE);
                this.notification.setContentIntent(getMainPendingIntent());
                Intent intent = new Intent(this, getClass());
                Intent intent2 = new Intent(this, getClass());
                intent.setAction("RECONNECT");
                intent2.setAction("STOP_SSH");
                this.notification.addAction(R.color.colorPrimary,"Reconnect", PendingIntent.getService(this, 0, intent, 0));
                this.notification.addAction(R.color.colorPrimary, "Stop", PendingIntent.getService(this, 1, intent2, 1));
                Util.setSmallNotificationIcon(notification);
                Notification notif = notification.getNotification();
                notificationManager.notify(1, notif);
                startForeground(1, notif);
                Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                Ringtone r = RingtoneManager.getRingtone(getApplicationContext(), notification);
                r.play();
            }}
        else
        if (state == R.string.state_disconnected)
        {
            stopForeground(true);
        }
        else
        {
            notificationManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

            this.notification = new Notification.Builder(this);

            notification = new Notification.Builder(this);
            notification.setColor(Color.rgb(244, 67, 54));
            String title = settings.getBoolean("custom_tweak", false) ? "Custom" : settings.getString("TweakName", "");
            notification.setContentTitle(getString(R.string.app_name) + " - " + settings.getString("SSHName", "") + " using " + title);
            notification.setContentText(getString(state));

            if (Build.VERSION.SDK_INT >= 23)
            {
                notification.setSmallIcon(getIcon(state));
                notification.setColor(Color.TRANSPARENT);
            }
            else
            {
                notification.setSmallIcon(getIcon(state));
            }
            notification.setSound(RingtoneManager.getDefaultUri(2));
            this.notification.setOnlyAlertOnce(true);
            this.notification.setOngoing(true);
            notification.setUsesChronometer(true);
            this.notification.setPriority(Integer.MAX_VALUE);
            this.notification.setContentIntent(getMainPendingIntent());
            Intent intent = new Intent(this, getClass());
            Intent intent2 = new Intent(this, getClass());
            intent.setAction("RECONNECT");
            intent2.setAction("STOP_SSH");
            this.notification.addAction(R.color.colorPrimary,"Reconnect", PendingIntent.getService(this, 0, intent, 0));
            this.notification.addAction(R.color.colorPrimary, "Stop", PendingIntent.getService(this, 1, intent2, 1));
            Util.setSmallNotificationIcon(notification);
            Notification notif = notification.getNotification();
            notificationManager.notify(1, notif);
            startForeground(1, notif);
        }}


    @SuppressLint("WrongConstant")
    private void createNotificationChannel(NotificationManager notificationManager)
    {
        NotificationChannel notificationChannel = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationChannel = new NotificationChannel("ssh", "SSH  notificacao", 3);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationChannel.setShowBadge(true);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }


    @SuppressLint("WrongConstant")
    private PendingIntent getMainPendingIntent()
    {
        try
        {
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(67108864);

            return PendingIntent.getActivity(this, 0, intent, 0);
        }


        catch (Exception e)
        {
            throw new NoClassDefFoundError(e.getMessage());
        }
    }


    private int getIcon(int state)
    {
        switch (state)
        {
            case R.string.state_connected:
                return R.drawable.ic_cloud;
            case R.string.state_connecting:
                return R.drawable.ic_connecting;
            case R.string.state_auth:
                return R.drawable.ic_connecting;
        }
        return R.mipmap.ic_launcher;
    }

    private void vpn_handler(boolean on)
    {
        if (on)
        {
            if (mVpnThread != null)
            {
                mVpnThread.interrupt();
            }
            mVpnThread = new Thread(new Runnable() {
                @Override
                public void run()
                {

                    try
                    {
                        if (!establishVpn())
                        {
                            log("Failed to establish the VPN");
                            return;
                        }
                        connectTunnel(getLocalServerAddress("1080"), getLocalServerAddress("7300"), settings.getBoolean("udp_forwarder", true));

                    }
                    catch (Exception e)
                    {

                    }
                }
            }, "myVPNThread");
            mVpnThread.start();
        }
        else
        {
            if (mVpnThread != null)
            {
                mVpnThread.interrupt();
                mVpnThread = null;
            }
            disconnectTunnel();
        }

    }



    public synchronized boolean establishVpn()
    {
        log("Starting VPN service..");
        try
        {
            Locale.setDefault(Locale.ENGLISH);
            privateIpAddress = Util.selectPrivateAddress();
            String subnet = Util.getPrivateAddressSubnet(privateIpAddress);
            int prefixLength = Util.getPrivateAddressPrefixLength(privateIpAddress);
            mRouter = Util.getPrivateAddressRouter(privateIpAddress);
            VpnService.Builder builder = new VpnService.Builder();
            builder.setSession(getApplicationName());
            String release = Build.VERSION.RELEASE;
            if ((Build.VERSION.SDK_INT == Build.VERSION_CODES.KITKAT && !release.startsWith("4.4.3")
                    && !release.startsWith("4.4.4") && !release.startsWith("4.4.5") && !release.startsWith("4.4.6"))
                    && mMtu < 1280)
            {
                mMtu = 1280;
                builder.setMtu(mMtu);
            }
            builder.setMtu(mMtu);
            builder.addAddress(privateIpAddress, prefixLength);
            mRoutes.addIP(new CIDRIP("0.0.0.0", 0), true);
            mRoutes.addIP(new CIDRIP("10.0.0.0", 8), false);
            mRoutes.addIP(new CIDRIP("192.168.42.0", 23), false);
            mRoutes.addIP(new CIDRIP("192.168.44.0", 24), false);
            mRoutes.addIP(new CIDRIP("192.168.49.0", 24), false);
            boolean allowUnsetAF = Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ;
            if (allowUnsetAF)
            {
                allowAllAFFamilies(builder);

            }

            if (settings.getBoolean("dns_forwarder", true))
            {
                String xdns = settings.getString("dns_forward", "");
                String[] dns = xdns.isEmpty() ? "8.8.8.8;8.8.4.4".split(";") : xdns.split(";");
                String dns_1 = dns[0];
                String dns_2 = dns[1];

                builder.addDnsServer(dns_1);
                builder.addDnsServer(dns_2);
                String pdnsd_path = getFilesDir().getCanonicalPath() + "/";
                File file = new File(getCacheDir().getCanonicalPath(), "pdnsd.cache");
                if (file.exists())
                {
                    file.delete();
                }
                file.createNewFile();
                if (file.setReadable(true) && file.setWritable(true))
                {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(this.getApplicationInfo().nativeLibraryDir);
                    String string22 = stringBuilder.toString();



                    String format = String.format(b(this, R.raw.pdnsd_conf), new Object[]{getCacheDir().getCanonicalPath(), "0.0.0.0", dns_1, dns_2});
                    FileOutputStream openFileOutput = openFileOutput("a.conf", 0);
                    openFileOutput.write(format.getBytes());
                    openFileOutput.flush();
                    openFileOutput.close();
                    pdnsdProcess = new ProcessBuilder(new String[0]).command(new String[]{string22 + "/libpdnsd.so", "-c", pdnsd_path + "a.conf"}).redirectErrorStream(false).start();
                    pdnsdProcess.getOutputStream().close();
                }
                else
                {
                    log("Can't set read-write pdnsd.cache, pdnsd aborted");
                }
                mRoutes.addIP(new CIDRIP(dns_1, 32), true);
                mRoutes.addIP(new CIDRIP(dns_2, 32), true);


            }
            Collection<NetworkSpace.ipAddress> positiveIPv4Routes = mRoutes.getPositiveIPList();

            NetworkSpace.ipAddress multicastRange = new NetworkSpace.ipAddress(new CIDRIP("224.0.0.0", 3), true);

            for (NetworkSpace.ipAddress route : positiveIPv4Routes)
            {
                try
                {
                    if (!multicastRange.containsNet(route))
                    {
                        builder.addRoute(route.getIPv4Address(), route.networkMask);
                    }
                }
                catch (IllegalArgumentException ia)
                {
                    log("Route rejected by Android" + route + " " + ia.getLocalizedMessage());
                }
            }

            String excluded = TextUtils.join(", ", mRoutes.getNetworks(false)).replace(conts.getSSHHost(), Util.allStar(conts.getSSHHost()));
            log("Routes: " + TextUtils.join(", ", mRoutes.getNetworks(true)));
            log("Routes excluded: " + excluded);

            mRoutes.clear();
            tunFd = builder.establish();
            return tunFd != null;
        }
        catch (Exception e)
        {
            log("Failed to establish the VPN " + e);
        }
        return false;

    }

    public synchronized void connectTunnel(final String socksServerAddress, final String udpServerAddress, final boolean remoteUdpForwardingEnabled)
    {
        if (socksServerAddress == null)
        {
            throw new IllegalArgumentException("Must provide an IP address to a SOCKS server.");
        }
        if (tunFd == null)
        {
            throw new IllegalStateException("Must establish the VPN before connecting the tunnel.");
        }
        if (tun2socksThread != null)
        {
            throw new IllegalStateException("VPN tunnel already connected");
        }
        tun2socksThread =
                new Thread() {
                    public void run()
                    {
                        Tun2Socks.Start(tunFd.detachFd(),
                                mMtu,
                                mRouter,
                                "255.255.255.0",
                                socksServerAddress,
                                udpServerAddress,
                                String.valueOf(privateIpAddress + ":9395"),
                                remoteUdpForwardingEnabled);
                    }
                };
        tun2socksThread.start();
        VPNLog.logInfo("<font>Telegram:\n"+"t.me/khaledagn</font>");
        VPNLog.logInfo("<font>Instagram:\n"+"www.instagram.com/khaledagn</font>");
        VPNLog.logInfo("<font>Facebook:\n"+"facebook.com/khaledaggn</font>");
        VPNLog.logInfo("<font>Website:\n"+"www.khaledagn.com</font>");
        VPNLog.logInfo("<b><font color=\"#38761d\"> Copyright © 2021 - Khaled AGN </font></b>");
        log("<b>VPN Service Connected</b>");
        onStatusChanged(3);
    }

    /* Disconnects a tunnel created by a previous call to |connectTunnel|. */
    public synchronized void disconnectTunnel()
    {
        log("<b>Stopping VPN Service...</b>");
        if (pdnsdProcess != null)
        {
            pdnsdProcess.destroy();
            pdnsdProcess = null;
        }
        try
        {
            if (tunFd != null)
            {
                tunFd.close();
                tunFd = null;
            }

        }
        catch (IOException e)
        {
            log("Failed to close the VPN interface file descriptor.");
        }
        try
        {
            if (tun2socksThread != null)
            {
                Tun2Socks.Stop();
                tun2socksThread.join();
                tun2socksThread = null;
            }
        }
        catch (InterruptedException e)
        {
            Thread.currentThread().interrupt();
        }
        log("VPN Disconnected");

    }

    public static String b(Context context, int i)
    {
        Scanner useDelimiter = new Scanner(context.getResources().openRawResource(i), "UTF-8").useDelimiter("\\A");
        StringBuilder stringBuilder = new StringBuilder();
        while (useDelimiter.hasNext())
        {
            stringBuilder.append(useDelimiter.next());
        }
        useDelimiter.close();
        return stringBuilder.toString();
    }

    private void allowAllAFFamilies(VpnService.Builder builder)
    {
        if (conts.getSSHHost().equals((Object)LOCAL_SERVER_ADDRESS))
        {
            try
            {
                builder.addDisallowedApplication("net.agn.vpn");
                VPNLog.logInfo("Slowdns Bypass OK ✔");
            }
            catch (PackageManager.NameNotFoundException ignored)
            {

            }
        }



        builder.allowFamily(OsConstants.AF_INET);
        builder.allowFamily(OsConstants.AF_INET6);
    }

    public synchronized String getLocalServerAddress(String port) throws IllegalStateException
    {
        return String.format(Locale.ROOT, "%s:%s", LOCAL_SERVER_ADDRESS, port);
    }

    public final String getApplicationName() throws PackageManager.NameNotFoundException
    {
        PackageManager packageManager = getApplicationContext().getPackageManager();
        ApplicationInfo appInfo = packageManager.getApplicationInfo(getPackageName(), 0);
        return (String) packageManager.getApplicationLabel(appInfo);
    }

}


package net.agn.vpn.util;

import android.content.*;
import android.preference.*;
import android.content.SharedPreferences.*;
import net.agn.vpn.R;

public class Constants
{

    private SharedPreferences prefs;
    private SharedPreferences.Editor editor;
    public Constants(Context context)
    {
        prefs = PreferenceManager.getDefaultSharedPreferences(context);
        editor = prefs.edit();
    }

    public boolean rede() {
        return prefs.getBoolean("enabled", true);
    }
    public boolean screen() {
        return prefs.getBoolean("lockscreen", true);
    }

    public boolean isDirect() {
        return prefs.getBoolean("DirectEnable", false);
    }
    public boolean isCustom() {
        return prefs.getBoolean("custom_tweak", false);
    }
    public boolean isDirectP() {
        return prefs.getBoolean("DirectPEnable", false);
    }

    public boolean isSSL() {
        return prefs.getBoolean("SSLEnable", false);
    }
    public int getTunMode()
    {
        return prefs.getInt("TunMode", 0);
    }
    public String getSSHHost()
    {
        return prefs.getString("SSH_HOST","rgnet.sshbr.online");
    }
    public int getSSHPort()
    {
        return Integer.parseInt(prefs.getString("SSH_PORT","22"));
    }
    public int getSSHDropbear()
    {
        return Integer.parseInt(prefs.getString("SSH_Dropbear","555"));
    }
    public int getSSLPort()
    {
        return Integer.parseInt(prefs.getString("SSL_PORT","443"));
    }
    public String getSSHPortString()
    {
        return prefs.getString("SSH_PORT", "22");
    }
    public String getUsername()
    {
        return prefs.getString("USERNAME","");
    }
    public String getPassword()
    {
        return prefs.getString("PASSWORD","");
    }
    public String getHostUrl()
    {
        return prefs.getString("HOST_URL","");
    }
    public String getPayload()
    {
        return prefs.getString("HTTP_PAYLOAD","");
    }
    public String getCustomP()
    {
        return prefs.getString("CUSTOM_PAYLOAD","");
    }
    public String getProxy()
    {
        return prefs.getString("PROXY_HOST", "");
    }
    public int getProxyPort()
    {
        return Integer.parseInt(prefs.getString("PROXY_PORT", "0"));

    }
    public int getLocalPort()
    {
        return Integer.parseInt(prefs.getString("LOCAL_PORT", "8989"));
    }

    public String getConfigVersion()
    {
        return prefs.getString("CurrentConfigVersion", "1.0");
    }

    public void setConfigVersion(String version)
    {
        editor.putString("CurrentConfigVersion", version).apply();
    }
    public void setCustomEnable(boolean z) {
        editor.putBoolean("custom_tweak", z).apply();
    }
    public void setDirectEnable(boolean z) {
        editor.putBoolean("DirectEnable", z).apply();
    }
    public void setDirectPEnable(boolean z) {
        editor.putBoolean("DirectPEnable", z).apply();
    }
    public void setSSLEnable(boolean z) {
        editor.putBoolean("SSLEnable", z).apply();
    }
    public void setTunMode(int mode)
    {
        editor.putInt("TunMode", mode).apply();
    }
    public void setHostUrl(String url)
    {
        editor.putString("HOST_URL", url).apply();
    }
    public void setHTTPayload(String payload)
    {
        editor.putString("HTTP_PAYLOAD", payload).apply();
    }
    public void setCustomP(String payload)
    {
        editor.putString("CUSTOM_PAYLOAD", payload).apply();
    }
    public void setProxy(String proxy)
    {
        editor.putString("PROXY_HOST", proxy).apply();
    }
    public void setProxyPort(String port)
    {
        editor.putString("PROXY_PORT", port).apply();
    }
    public void setLocalPort(String localport)
    {
        editor.putString("LOCAL_PORT", localport).apply();
    }
    public void setSSHHost(String host)
    {
        editor.putString("SSH_HOST", host).apply();
    }
    public void setSSHPort(String port)
    {
        editor.putString("SSH_PORT", port).apply();
    }
    public void setSSHDropbear(String port)
    {
        editor.putString("SSH_Dropbear", port).apply();
    }
    public void setSSLPort(String port)
    {
        editor.putString("SSL_PORT", port).apply();
    }
    public void setUsername(String username)
    {
        editor.putString("USERNAME", username).apply();
    }

    public void setDns(String dnsname)
    {
        editor.putString("DNSname", dnsname).apply();
    }


    public void setSlowchave(String slowchave)
    {
        editor.putString("SLOWCHAVE", slowchave).apply();
    }


    public String isdns() {
        return prefs.getString("DNSNAME", "");
    }



    public void setSlowHost(String slowhost)
    {
        editor.putString("SLOWHOSR", slowhost).apply();
    }



    public void setPassword(String password)
    {
        editor.putString("PASSWORD", password).apply();
    }
}

package net.agn.vpn;

public class App
{
}

package net.agn.vpn;

import android.annotation.SuppressLint;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import cn.pedant.SweetAlert.SweetAlertDialog;
import androidx.annotation.NonNull;
import androidx.core.view.GravityCompat;
import androidx.core.widget.*;
import androidx.appcompat.app.*;
import androidx.appcompat.*;
import android.text.*;
import android.util.*;
import android.view.*;
import android.widget.*;

import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.shashank.sony.fancydialoglib.*;
import es.dmoral.toasty.Toasty;
import java.io.*;
import java.util.*;

import net.agn.vpn.core.*;
import net.agn.vpn.db.*;
import net.agn.vpn.fragment.*;
import net.agn.vpn.logger.*;
import net.agn.vpn.model.*;
import net.agn.vpn.speedo.*;
import net.agn.vpn.util.*;
import net.agn.vpn.view.*;
import org.bitvise.*;
import org.json.*;
import com.onesignal.OneSignal;

import androidx.appcompat.app.AlertDialog;
import net.agn.vpn.R;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.drawerlayout.widget.DrawerLayout;

import com.shashank.sony.fancydialoglib.Icon;
import java.lang.Process;


public class MainActivity extends MainBase implements SSHTunnelService.StatusChangeListener
{
    private static final String ONESIGNAL_APP_ID = "d4db7e55-0cbd-45e2-a472-7bf8134cb269";
    private CenteredToolBar toolbar;



    private Button btnAcc;

    private Activity activity;

    private TorrentDetection torrent;

    private TextView ipAddress;

    private ImageView v;

    TextView textView;

    private SharedPreferences settings;



    private static final String LOCATION = "Location";


    private Process dnsProcess;
    private File filedns;
    private static final String DNS_BIN = "libstartdns";

    private static Process proceso;


    private AlertDialog.Builder adb;
    private boolean isBounded;
    private TrafficService backgroundService;

    /**
     * Connection class between the activity and the service to be able to invoke service methods
     */
    private final ServiceConnection mConnection = new ServiceConnection() {

        public void onServiceDisconnected(ComponentName name)
        {
            isBounded = false;
            backgroundService = null;
        }

        public void onServiceConnected(ComponentName name, IBinder service)
        {
            isBounded = true;
            TrafficService.LocalBinder mLocalBinder = (TrafficService.LocalBinder) service;
            backgroundService = mLocalBinder.getServerInstance();
        }
    };

    /**
     * OnStart method of the activity that establishes a connection with the service by binding to it
     */
    @Override
    protected void onStart()
    {
        super.onStart();
        Intent serviceIntent = new Intent(getApplicationContext(), TrafficService.class);
        startService(serviceIntent);
        bindService(serviceIntent, mConnection, BIND_AUTO_CREATE);
    }

    /**
     * OnStop method of the activity that destroys the connection with the service by unbinding from
     * it
     */
    @Override
    protected void onStop()
    {
        super.onStop();
        if (isBounded)
        {
            unbindService(mConnection);
            isBounded = false;
        }
    }

    @Override
    public void onBackPressed()
    {

        AlertDialog.Builder builder3 = new AlertDialog.Builder(MainActivity.this);
        builder3.setMessage("IF THE VPN IS RUNNING CLICK MINIMIZE");
        builder3.setPositiveButton("EXIT", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface p1, int p2)
            {
                // TODO: Implement this method
                if (android.os.Build.VERSION.SDK_INT >= 21)
                {
                    finishAndRemoveTask();
                }
                else
                {
                    android.os.Process.killProcess(android.os.Process.myPid());
                }
                System.exit(0);
            }
        });
        builder3.setNegativeButton("MINIMIZE", new DialogInterface.OnClickListener() {
            @SuppressLint("WrongConstant")
            @Override
            public void onClick(DialogInterface p1, int p2)
            {
                // TODO: Implement this method
                Intent intent = new Intent("android.intent.action.MAIN");
                intent.addCategory("android.intent.category.HOME");
                intent.setFlags(268435456);
                startActivity(intent);
            }
        });
        builder3.setNeutralButton("CANCEL", null);
        builder3.show();
    }

    @SuppressLint("ResourceType")
    @Override
    public void onStatusChanged(int status)
    {
        switch (status)
        {
            case 0:
                // snack("Connecting...");
                break;
            case 1:
                //snack("Authentication Failed!");
                break;
            case 2:
                rippleBackground.stopRippleAnimation();
                rippleBackground.setRippleColor(Color.parseColor(getString(R.color.colorDisconnected)));
                rippleBackground.startRippleAnimation();
                //snack("Disconnected");
                torrent.stop();
                ipAddress.setText(Util.getIpAddress());

                break;
            case 3:
                rippleBackground.stopRippleAnimation();
                rippleBackground.setRippleColor(Color.parseColor(getString(R.color.colorConnected)));
                rippleBackground.startRippleAnimation();
                torrent.start();
                //snack("Connected");
                ipAddress.setText(Util.getIpAddress());

                break;
        }

    }

    @Override
    public void onLogReceived(String logString)
    {
        // hotdog
    }

    private CuboidButton start_vpn;
    private Constants conts;
    private static final int REQUEST_CODE = 0;
    private DrawerLayout drawerLayout;
    public ArrayList<String> serverList = new ArrayList();
    public ArrayList<String> dnsList = new ArrayList();
    public ArrayList<String> tweakList = new ArrayList();
    private Spinner mServer;
    private ArrayAdapter serverAdapt;
    private DataBaseHelper db;
    private SharedPreferences sp;
    private Spinner mTweak;
    private Spinner mDns;
    private ArrayAdapter tweakAdapt;
    private ArrayAdapter dnsAdapt;

    private CoordinatorLayout coordinatorLayout;
    private TextView vpn_status;
    private RippleBackground rippleBackground;

    private static final int MY_PERMISSION_ACCESS_COARSE_LOCATION = 11;
    public void block(){
        new SweetAlertDialog(MainActivity.this, SweetAlertDialog.CUSTOM_IMAGE_TYPE)
                .setTitleText("APPL"+"ICAT"+"ION M"+"OD"+"IF"+"IE"+"D")
                .setContentText("Better"+"look for"+"another"+"APP")
                .setConfirmText("Del"+"ete")
                .setCustomImage(R.drawable.ic_block)
                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                    @Override
                    public void onClick(SweetAlertDialog sDialog) {
                        sDialog.dismissWithAnimation();

                        // TODO: Implement this method
                        if (android.os.Build.VERSION.SDK_INT >= 21) {
                            finishAndRemoveTask();
                        } else {
                            android.os.Process.killProcess(android.os.Process.myPid());
                        }
                        System.exit(0);
                    }
                })
                .show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
        OneSignal.initWithContext(this);
        OneSignal.setAppId(ONESIGNAL_APP_ID);

        Thread.setDefaultUncaughtExceptionHandler(new ExceptionHandler(this));
        VPNLog.clearLog();


        doBind();
        SSHTunnelService.addOnStatusChangedListener(this);

        settings = getSharedPreferences("pref", MODE_PRIVATE);




        conts = new Constants(this);
        db = new DataBaseHelper(this);
        sp = TcodesApplication.getSharedPreferences();
        if (new Boolean(sp.getBoolean("firstStart", true)).booleanValue())
        {
            try
            {
                db.insertData(Constraints.defconf);
                final JSONObject obj = new JSONObject(db.getData());
                conts.setConfigVersion(obj.getString("Version"));
                showBoasVindas();
                sp.edit().putBoolean("firstStart", false).commit();
            }
            catch (Exception e)
            {

            }
        }
        setContentView(R.layout.activity_main);

//
//		if (android.os.Build.VERSION.SDK_INT > 23) {
//
//		if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
//		{
//			ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSION_ACCESS_COARSE_LOCATION);
//		}}
//
        torrent = new TorrentDetection(this, Constraints.torrentList, new TorrentDetection.TorrentListener() {
            @Override
            public void detected(ArrayList pkg)
            {

                if (sp.getString("SSHHost", "").toString().equals((Object)"127.0.0.1"))
                {

                    stopdns();
                }


                stopService();

                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("SNIFFER DETECTED!!!")

                        .setMessage("Uninstall Apps:  " + String.format("%s", new Object[]{TextUtils.join(", ", (String[]) pkg.toArray(new String[pkg.size()]))}))
                        .setPositiveButton("OK", null)
                        //setAnimation(Animation.SLIDE)
                        .setCancelable(false)
                        .create()
                        //.setIcon(R.mipmap.ic_info, Icon.Visible)
                        .show();
            }
        });

        coordinatorLayout = (CoordinatorLayout) findViewById(R.id.coordinator);
        setupToolbar(null);
        vpn_status = (TextView)findViewById(R.id.vpn_status);
        rippleBackground = (RippleBackground) findViewById(R.id.content);


        start_vpn = (CuboidButton)findViewById(R.id.connect);
        start_vpn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View p1)
            {



//					if (new Boolean(sp.getBoolean("velocidade", true)).booleanValue() &&   settings.getString("ativado", "").toString().equals((Object)"on"))
//					{
//						SharedPreferences.Editor editor = settings.edit();
//						editor.putString("ativado","off");
//						editor.apply();
//
//					}else{
//
//						if (new Boolean(sp.getBoolean("velocidade", true)).booleanValue() &&   settings.getString("ativado", "").toString().equals((Object)"off"))
//						{
//							SharedPreferences.Editor editor = settings.edit();
//							editor.putString("ativado","on");
//							editor.apply();}
//
//
//					}




                if (InjectorService.isRunning)
                {

                    if (sp.getString("SSHHost", "").toString().equals((Object)"127.0.0.1"))
                    {

                        stopdns();
                    }
                    stopService();

                }  else
                {
                    if (isConnected())
                    {


                        if (sp.getString("SSHHost", "").toString().equals((Object)"127.0.0.1"))
                        {
                            try
                            {
                                Toasty.info(getApplicationContext(), "SLOWDNS REDUCED SPEED", Toast.LENGTH_SHORT, true).show();

                                startdnsvoid();

                                //toast(" -udp "+ sp.getString("DNSname", "")+ ":53   -pubkey "+ sp.getString("Slowchave", "").toString()+ " "+ sp.getString("Slowhost", "").toString()+ " 127.0.0.1:2222");

                            }
                            catch (IOException e)
                            {

                            }}

                        startVPN();
                    }
                }
            }
        });
        mServer = (Spinner) findViewById(R.id.serverSpin);
        parseServer();
        serverAdapt = new ArrayAdapter(this, R.layout.spinner_dropdown_item, serverList);
        mServer.setAdapter(serverAdapt);
        mServer.setSelection(sp.getInt("ServerSpin", 0));
        mServer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
            {
                try
                {
                    JSONArray jarr = new JSONObject(db.getData()).getJSONArray("Servers");
                    JSONObject obj = jarr.getJSONObject(p3);
                    sp.edit().putString("SSHName", obj.getString("Name")).commit();
                    sp.edit().putString("SSHHost", obj.getString("SSHHost")).commit();
                    sp.edit().putString("USERNAME", obj.getString("USERNAME")).commit();
                    sp.edit().putString("PASSWORD", obj.getString("PASSWORD")).commit();
                    sp.edit().putString("SSHPort", obj.getString("SSHPort")).commit();
                    sp.edit().putString("DropBear", obj.getString("DropBear")).commit();
                    sp.edit().putString("SSLPort", obj.getString("SSLPort")).commit();
                    sp.edit().putString("ProxyPort", obj.getString("ProxyPort")).commit();
                    sp.edit().putInt("ServerSpin", p3).commit();

                    if (sp.getString("SSHHost", "").toString().equals((Object)"127.0.0.1"))
                    {
                        mDns.setEnabled(true);
                    }
                    else
                        mDns.setEnabled(false);

                }

                catch (Exception e)
                {
                    //toast(e.getMessage());
                }

                //e.printStackTrace()


            }
            @Override
            public void onNothingSelected(AdapterView<?> p1)
            {

            }
        });
        mTweak = (Spinner) findViewById(R.id.tweakSpin);
        parseTweak();
        tweakAdapt = new ArrayAdapter(this, R.layout.spinner_dropdown_item, tweakList);
        mTweak.setAdapter(tweakAdapt);
        mTweak.setSelection(sp.getInt("TweakSpin", 0));
        mTweak.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
            {
                try
                {
                    if (p1.getItemAtPosition(p3).toString().equals("Direct"))
                    {
                        conts.setDirectEnable(true);
                        sp.edit().putString("TweakName", "Direct").commit();
                        sp.edit().putBoolean("isDirectP", false).commit();
                        sp.edit().putBoolean("isSSL", false).commit();

                    }
                    else
                    {
                        conts.setDirectEnable(false);
                        JSONArray jarr = new JSONObject(db.getData()).getJSONArray("Tweaks");
                        //JSONObject obj = jarr.getJSONObject(p3 - 1);
                        JSONObject obj = jarr.getJSONObject(p3 - 0);
                        sp.edit().putString("TweakName", obj.getString("Name")).commit();
                        //conts.setHTTPayload(obj.getString("Payload"));
                        sp.edit().putBoolean("isDirectP", obj.getBoolean("Direct")).commit();
                        sp.edit().putBoolean("isSSL", obj.getBoolean("SSL")).commit();
                        sp.edit().putString("Slowchave", obj.getString("Slowchave")).commit();
                        sp.edit().putString("Slowhost", obj.getString("Slowhost")).commit();
                        sp.edit().putString("Payload", obj.getString("Payload")).commit();
                        sp.edit().putBoolean("CustomProxy", obj.getBoolean("CustomProxy")).commit();
                        sp.edit().putString("cProxyHost", obj.getString("ProxyHost")).commit();
                        sp.edit().putString("cProxyPort", obj.getString("ProxyPort")).commit();

                    }
                    sp.edit().putInt("TweakSpin", p3).commit();
                }
                catch (Exception e)
                {
                    // toast(e.getMessage());
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> p1)
            {

            }
        });




        mDns= (Spinner) findViewById(return.id.DnsSpin);
        parseDNs();
        dnsAdapt = new ArrayAdapter(this, R.layout.spinner_dropdown_item, dnsList);
        mDns.setAdapter(dnsAdapt);
        mDns.setSelection(sp.getInt("DNS", 0));
        mDns.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> p1, View p2, int p3, long p4)
            {
                try
                {
                    JSONArray jarr = new JSONObject(db.getData()).getJSONArray("DNS");
                    JSONObject obj = jarr.getJSONObject(p3);
                    sp.edit().putString("Name", obj.getString("Name")).commit();
                    sp.edit().putString("DNSname", obj.getString("DNSname")).commit();


                }
                catch (Exception e)
                {
                    //  toast(e.getMessage());
                }

                sp.edit().putInt("DNS", p3).commit();
            }

            @Override
            public void onNothingSelected(AdapterView<?> p1)
            {

            }
        });

        NavigationView navigationView = (NavigationView) findViewById(R.id.shitstuff);
        View header=navigationView.getHeaderView(0);
        ipAddress = (TextView) header.findViewById(R.id.version);
        ipAddress.setText(Util.getIpAddress());



        addSwitch(navigationView, R.id.som_notify, "som_notify", true, new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                sp.edit().putBoolean("som_notify", isChecked).commit();
            }
        });

        addSwitch(navigationView, R.id.dns_forwarder, "dns_forwarder", true, new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                sp.edit().putBoolean("dns_forwarder", isChecked).commit();
            }
        });
        addSwitch(navigationView, R.id.udp_forwarder, "udp_forwarder", true, new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                sp.edit().putBoolean("udp_forwarder", isChecked).commit();
            }
        });
        addSwitch(navigationView, R.id.cpu_wakelock, "cpu_wakelock", true, new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                sp.edit().putBoolean("cpu_wakelock", isChecked).commit();


            }
        });

        addSwitch(navigationView, R.id.notificacao, "velocidade", true, new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
            {
                sp.edit().putBoolean("velocidade", isChecked).commit();

                if (sp.getBoolean("velocidade", true))
                {
                    //sp.edit().putBoolean("velocidade", false).commit();
                    Toasty.success(getApplicationContext(), "SPEED STATUS ACTIVATED", Toast.LENGTH_LONG, true).show();
                }
                else
                    //sp.edit().putBoolean("velocidade", true).commit();
                    //toast("STATUS VELOCIDADE DESATIVADO");
                Toasty.error(getApplicationContext(), "SPEED STATUS DISABLED", Toast.LENGTH_LONG, true).show();


            }

        });


        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {

            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem)
            {
                drawerLayout.closeDrawers();
                switch (menuItem.getItemId())
                {
                    case R.id.update:
                        snack("the update is automatic!");
                        return true;

                    case R.id.geo_location:
                        new UpdateCore(MainActivity.this, "http://ip-api.com/json", new UpdateCore.Listener() {
                            @Override
                            public void onLoading()
                            {
                                //snack("fetching..");
                            }

                            @Override
                            public void onCompleted(String config) throws Exception
                            {
                                JSONObject geo = new JSONObject(config);
                                StringBuffer sb = new StringBuffer();
                                sb.append("\n").append("ISP: ").append(geo.getString("isp"));
                                sb.append("\n").append("Time Zone: ").append(geo.getString("timezone"));
                                sb.append("\n").append("Country Code: ").append(geo.getString("countryCode"));
                                sb.append("\n").append("Country: ").append(geo.getString("country"));
                                sb.append("\n").append("Region: ").append(geo.getString("regionName"));
                                sb.append("\n").append("City: ").append(geo.getString("city"));

                                new SweetAlertDialog(MainActivity.this, SweetAlertDialog.CUSTOM_IMAGE_TYPE)
                                        .setTitleText("Location!")
                                        .setCustomImage(R.drawable.geo_map)
                                        .setContentText(sb.toString())

                                        .show();

                            }

                            @Override
                            public void onCancelled()
                            {

                            }

                            @Override
                            public void onException(String ex)
                            {
                                snack(ex);
                            }
                        }).execute();
                        return true;
                    case R.id.channel:
                        Intent w = new Intent("android.intent.action.VIEW", Uri.parse("https://t.me/khaledagn"));
                        startActivity(w);
                        return true;
                    case R.id.group:
                        Intent g = new Intent("android.intent.action.VIEW", Uri.parse("https://www.instagram.com/khaledagn"));
                        startActivity(g);
                        return true;

                    case R.id.contact:
                        Intent c = new Intent("android.intent.action.VIEW", Uri.parse("https://www.youtube.com/channel/UCA2FDRkzRSf5xRpm8nRt7_A"));
                        startActivity(c);
                        return true;
                    case R.id.dns_forwarder:
                        new DNSDialog(MainActivity.this).show();
                        return true;
                    case R.id.cpu_wakelock:
                        return true;
                    case R.id.notificacao:

                        return true;
                    default:
                        //snack("Coming Soon!");
                        return true;

                }
            }
        });
        drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.app_name, R.string.app_name);
        drawerLayout.setDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        v = (ImageView) findViewById(R.id.scrl);
        View persistentbottomSheet = coordinatorLayout.findViewById(R.id.bottomsheet);
        final BottomSheetBehavior behavior = BottomSheetBehavior.from(persistentbottomSheet);
        behavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {

            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState)
            {
                switch (newState)
                {
                    case BottomSheetBehavior.STATE_HIDDEN:
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED:
                        v.animate().setDuration(500).rotation(0);
                        break;
                    case BottomSheetBehavior.STATE_COLLAPSED:
                        v.animate().setDuration(300).rotation(180);
                        break;
                    case BottomSheetBehavior.STATE_DRAGGING:
                        break;
                    case BottomSheetBehavior.STATE_SETTLING:
                        behavior.setHideable(false);
                        break;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset)
            {

            }
        });
        ((RelativeLayout) findViewById(R.id.bottom_sheet_header)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if (behavior.getState() != BottomSheetBehavior.STATE_EXPANDED)
                {
                    behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                    //btnBottomSheet.setText(R.string.close);
                }
                else
                {
                    behavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                    //btnBottomSheet.setText(R.string.expand);
                }
            }
        });
    }



    public void addSwitch(NavigationView navView, int id, final String tag, boolean defval, CompoundButton.OnCheckedChangeListener listener)
    {
        MenuItem bleh = navView.getMenu().findItem(id);
        bleh.setActionView(new Switch(this));
        Switch dnsSwitch =(Switch) bleh.getActionView();
        dnsSwitch.setChecked(sp.getBoolean(tag, defval));
        dnsSwitch.setOnCheckedChangeListener(listener);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.home_menu, menu);
        // TODO: Implement this method
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.menu_about:


                startActivity(new Intent(MainActivity.this, AboutActivity.class));
                break;
        }
        // TODO: Implement this method
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("ConstantConditions")
    private void setupToolbar(String title)
    {
        toolbar = (CenteredToolBar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (title != null)
        {
            getSupportActionBar().setTitle(title);
        }
        else
        {
            ActivityInfo activityInfo;
            try
            {
                activityInfo = getPackageManager().getActivityInfo(getComponentName(), PackageManager.GET_META_DATA);
                String currentTitle = activityInfo.loadLabel(getPackageManager()).toString();
                getSupportActionBar().setTitle(currentTitle);

            }
            catch (PackageManager.NameNotFoundException ignored)
            {

            }

        }

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

    }

    protected boolean isConnected()
    {
        boolean enabled = true;

        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = connectivityManager.getActiveNetworkInfo();

        if ((info == null || !info.isConnected() || !info.isAvailable()))
        {
            enabled = false;
            new SweetAlertDialog(MainActivity.this, SweetAlertDialog.ERROR_TYPE)
                    .setTitleText("NO CONNECTION :( ")
                    .setContentText("Failed to connect, please check your internet connection !!")
                    .setConfirmText("OK")
                    .show();
        }
        return enabled;
    }


    private boolean isEmpty(String str)
    {
        if (str.isEmpty())
        {
            return true;
        }
        return false;
    }


    private void startVPN()
    {

        conts.setUsername(sp.getString("USERNAME", "").toString());
        conts.setPassword(sp.getString("PASSWORD", ""));
        conts.setSSHHost(sp.getString("SSHHost", ""));
        conts.setSSHPort(sp.getString("SSHPort", ""));
        conts.setSSHDropbear(sp.getString("DropBear", ""));
        conts.setSSLPort(sp.getString("SSLPort", ""));
        conts.setHTTPayload(sp.getString("Payload", ""));
        conts.setDirectPEnable(sp.getBoolean("isDirectP", false));
        conts.setSSLEnable(sp.getBoolean("isSSL", false));
        if (!sp.getBoolean("CustomProxy", false))
        {
            conts.setProxy(sp.getString("SSHHost", ""));
            conts.setProxyPort(sp.getString("ProxyPort", ""));
        }
        else
        {
            conts.setProxy(sp.getString("cProxyHost", ""));
            conts.setProxyPort(sp.getString("cProxyPort", ""));
        }

        conts.setLocalPort("8989");
        if (isEmpty(conts.getUsername()))
        {
            snack("Please fill in username and password!");
        }
        else if (isEmpty(conts.getPassword()))
        {
            snack("Please fill in username and password!");
        }
        else
        {
            Intent intent = VpnService.prepare(this);
            if (intent != null)
            {
                startActivityForResult(intent, REQUEST_CODE);
            }
            else
            {
                onActivityResult(REQUEST_CODE, RESULT_OK, intent);
            }

        }}

    private void hatdog(boolean z)
    {
        if (z)
        {
            //a(false);
            Intent intent = new Intent(this, InjectorService.class);
            intent.setAction(InjectorService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26)
            {
                startForegroundService(intent);
                return;
            }
            else
            {
                startService(intent);
                return;
            }
        }
        if (SSHTunnelService.isServiceStarted())
        {
            IProtect.b();
        }
        if (InjectorService.isServiceStarted())
        {
            stopService(new Intent(this, InjectorService.class));
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        switch (requestCode)
        {
            case REQUEST_CODE:
                // LogFragment.clear();
                //a(true);
                Intent intent = new Intent(this, InjectorService.class);
                intent.setAction(InjectorService.ACTION_START);
				/*if (Build.VERSION.SDK_INT >= 26) {
				 startForegroundService(intent);
				 } else {*/
                startService(intent);
                //}
                //startService(new Intent(this, InjectorService.class).setAction(InjectorService.ACTION_START));
                break;
        }
        // TODO: Implement this method
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onInjectorConnected()
    {
        if (isActive())
        {
            //start_vpn.setCircle_border_color(Color.parseColor("blue"));
            start_vpn.setCr_icon(R.drawable.connected);
            enabledWidget(false);

        }
        else
        {

            start_vpn.setCr_icon(R.drawable.disconnected);
            enabledWidget(true);
        }
        super.onInjectorConnected();
    }



    @Override
    public void updateState(int state)
    {
        vpn_status.setText(state);
        // toast(getString(state));
        switch (state)
        {
            case R.string.state_connecting:
                break;
            case R.string.state_reconnecting:
                break;
            case R.string.state_auth:
                break;
            case R.string.state_connected:
                enabledWidget(true);
                if (new Boolean(sp.getBoolean("velocidade", true)).booleanValue() &&   settings.getString("ativado", "").toString().equals((Object)"on"))
                {SharedPreferences.Editor editor = settings.edit();
                    editor.putString("ativado","off");
                    editor.apply();}
                Toasty.success(getApplicationContext(), "CONNECTED", Toast.LENGTH_LONG, true).show();
                //toast("Conectado: PAGUE EM DIA");
                break;
            case R.string.state_disconnected:
                if (new Boolean(sp.getBoolean("velocidade", true)).booleanValue() &&   settings.getString("ativado", "").toString().equals((Object)"off"))
                {SharedPreferences.Editor editor = settings.edit();
                    editor.putString("ativado","on");
                    editor.apply();}
                Toasty.error(getApplicationContext(), "DISCONNECTED", Toast.LENGTH_LONG, true).show();
                enabledWidget(false);
                //toast("Desconectado");
                break;
        }
        onInjectorConnected();
        // TODO: Implement this method
        super.updateState(state);
    }

    private void snack(String msg)
    {
        Snackbar.make(coordinatorLayout, msg, Snackbar.LENGTH_SHORT).show();
    }

    private void toast(String msg)
    {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private void enabledWidget(boolean z)
    {
        mServer.setEnabled(z);
        if (sp.getBoolean("custom_tweak", false))
        {
            mTweak.setEnabled(false);
            mDns.setEnabled(false);

        }
        else
        {
            mTweak.setEnabled(z);
            mDns.setEnabled(z);

            if (sp.getString("SSHHost", "").toString().equals((Object)"127.0.0.1"))
            {
                mDns.setEnabled(z);}
            else

                mDns.setEnabled(false);
        }



    }
    @SuppressLint("ResourceType")
    @Override
    protected void onResume()
    {
        super.onResume();
        ipAddress.setText(Util.getIpAddress());
        SSHTunnelService.a(this);
        if (SSHTunnelService.connected)
        {

            vpn_status.setText("Connected");
            rippleBackground.stopRippleAnimation();
            rippleBackground.setRippleColor(Color.parseColor(getString(R.color.colorConnected)));
            rippleBackground.startRippleAnimation();

        }
        else
        {

            vpn_status.setText("Disconnected");
            rippleBackground.stopRippleAnimation();
            rippleBackground.setRippleColor(Color.parseColor(getString(R.color.colorDisconnected)));
            rippleBackground.startRippleAnimation();
        }

        update();
    }

    @Override
    protected void onDestroy()
    {
        doUnbind();
        super.onDestroy();
    }

    void parseServer()
    {
        try
        {
            JSONArray jarr = new JSONObject(db.getData()).getJSONArray("Servers");
            for (int i = 0; i < jarr.length(); i++)
            {
                JSONObject obj = jarr.getJSONObject(i);
                serverList.add(obj.getString("Name"));
            }
        }
        catch (JSONException e)
        {}
    }

    void parseTweak()
    {
        try
        {
            JSONArray jarr = new JSONObject(db.getData()).getJSONArray("Tweaks");


            for (int i = 0; i < jarr.length();i++)
            {
                JSONObject obj = jarr.getJSONObject(i);


                tweakList.add(obj.getString("Name"));
            }
        }
        catch (JSONException e)
        {
            Log.e("erro", e.toString());
            e.printStackTrace();
        }
    }

    protected void showBoasVindas() {
        new SweetAlertDialog(this, SweetAlertDialog.WARNING_TYPE)
                .setTitleText("Attention")
                .setContentText("This app was developed by Khaled AGN, and for advanced users only. If you don't know how to use this application, contact me.")
                .setConfirmText("OK")
                .show();
    }



    void refresh()
    {
        serverList.clear();
        parseServer();
        serverAdapt.notifyDataSetChanged();
        tweakList.clear();
        parseTweak();
        tweakAdapt.notifyDataSetChanged();

        parseDNs();
        dnsAdapt.notifyDataSetChanged();
    }

    public void offlinez(View v)
    {
        drawerLayout.openDrawer(GravityCompat.START);
    }

    public void monsa(View v)
    {
        Intent intentSettings = new Intent(this, AboutActivity.class);
        //intentSettings.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intentSettings);

    }


    void parseDNs()
    {
        try
        {
            JSONArray jarr = new JSONObject(db.getData()).getJSONArray("DNS");
            //tweakList.add("SELECIONE A OPERADORA");

            for (int i = 0; i < jarr.length();i++)
            {
                JSONObject obj = jarr.getJSONObject(i);
                dnsList.add(obj.getString("Name"));
            }
        }
        catch (JSONException e)
        {
            Log.e("error", e.toString());
            e.printStackTrace();
        }
    }


    private void stopdns()
    {

        //SharedPreferences.Editor editor = this.getSharedPreferences("pref", MODE_PRIVATE).edit();
        //editor.putString("a", "noreconnect");
        //editor.commit();

        filedns = CustomNativeLoader.loadNativeBinary(this, DNS_BIN, new File(this.getFilesDir(), DNS_BIN));

        if (filedns != null)
//dnsProcess.destroy();
            try
            {
                if (filedns != null)
                    KillThis.killProcess(filedns);
            }
            catch (Exception e)
            {}

        dnsProcess = null;
        filedns = null;

    }


    private	void startdnsvoid() throws IOException
    {

        final String string2 = this.getApplicationInfo().nativeLibraryDir;


        new Thread(new Runnable(){

            public void run()
            {

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string2).append("/libstartdns.so").toString();
                stringBuilder.append(" -udp ").append(sp.getString("DNSname", "")).append(":53   -pubkey ").append(sp.getString("Slowchave", "").toString()).append(" ").append(sp.getString("Slowhost", "").toString()).append(" 127.0.0.1:2222");

                String string22 = stringBuilder.toString();
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("SLOWDNS ");
                stringBuilder2.append(string22);

                try
                {
                    proceso = Runtime.getRuntime().exec(string22);
                    return;
                }
                catch (IOException EX)
                {

                    return;
                }
            }
        }).start();
        return;
    }
    private void restart_app() {
        Intent intent = new Intent(this, MainActivity.class);
        int i = 123456;
        PendingIntent pendingIntent = PendingIntent.getActivity(this, i, intent, PendingIntent.FLAG_CANCEL_CURRENT);
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC, System.currentTimeMillis() + ((long) 1000), pendingIntent);
        finish();
    }

    private void welcomeNotif(){

        NotificationManager notificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder notification = new Notification.Builder(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notification.setChannelId(this.getPackageName() + ".LeoDevz");
            createNotification(notificationManager, this.getPackageName() + ".LeoDevz");
        }

        notification.setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.contentup))
                .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_notyif))
                .setDefaults(Notification.DEFAULT_ALL)
                .setPriority(Notification.PRIORITY_HIGH)
                .setShowWhen(true)
                .setSmallIcon(R.drawable.ic_noty);
        notificationManager.notify(4130,notification.getNotification());
    }

    private void createNotification(NotificationManager notificationManager, String id)
    {
        NotificationChannel mNotif = null;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mNotif = new NotificationChannel(id, "LeoDevz", NotificationManager.IMPORTANCE_HIGH);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mNotif.setShowBadge(true);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(mNotif);
        }
        // TODO: Implement this method
    }
    void update()
    {
        new UpdateCore(this, Constraints.updater, new UpdateCore.Listener() {
            @Override
            public void onLoading()
            {

            }

            @Override
            public void onCompleted(final String config) {
                try {
                    final JSONObject obj = new JSONObject(MilitaryGradeEncrypt.decryptBase64StringToString(config, Constraints.confpass));
                    if (Double.valueOf(obj.getString("Version")) <= Double.valueOf(conts.getConfigVersion())) {

                    } else {
                        new SweetAlertDialog(MainActivity.this, SweetAlertDialog.CUSTOM_IMAGE_TYPE)
                                .setTitleText("New Update Available")
                                .setContentText("\n" + obj.getString("Message"))
                                .setConfirmText("Update Now!")
                                .setCustomImage(R.drawable.ic_update)
                                .setConfirmClickListener(new SweetAlertDialog.OnSweetClickListener() {
                                    @Override
                                    public void onClick(SweetAlertDialog sDialog) {
                                        sDialog.dismissWithAnimation();
                                        welcomeNotif();
                                        restart_app();

                                        try {
                                            db.updateData("1", config);
                                            sp.edit().putString("CurrentConfigVersion", obj.getString("Version")).commit();
                                            refresh();
                                        } catch (JSONException e) {}
                                    }
                                })
                                .show();
                    }
                } catch (Exception e) {
                    // Toast.makeText(MainActivity.this, e.getMessage() , 0).show();
                }
            }

            @Override
            public void onCancelled()
            {

            }

            @Override
            public void onException(String ex)
            {

            }
        }).execute();
    }
    public void account()
    {
        new AccountDialog(MainActivity.this).show();
    }

}

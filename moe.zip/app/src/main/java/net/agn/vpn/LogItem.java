package net.agn.vpn;

public class LogItem
{
	public String log;
	public String getLog()
	{
		return log;
	}
}

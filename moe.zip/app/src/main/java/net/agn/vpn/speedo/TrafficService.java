package net.agn.vpn.speedo;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.TrafficStats;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;

import androidx.core.app.NotificationCompat;
import android.telephony.TelephonyManager;
import android.text.format.Formatter;
import android.util.Log;

import net.agn.vpn.R;
import net.agn.vpn.util.Util;

public class TrafficService extends Service
{


	private SharedPreferences settings;
    private static final int ID = 8000;
	private static final String CMP = "com.android.settings.Settings$DataUsageSummaryActivity";
	private static NotificationHandler hndNotifier;
	private static ConnectivityManager mgrConnectivity;
	private static NotificationManager notificationManager;
	private static WifiManager mgrWireless;
	private static TelephonyManager mgrTelephony;
	private static Notification.Builder notBuilder;
	private final IBinder mBinder = new LocalBinder();
	private BroadcastReceiver recScreen;
	private final BroadcastReceiver recSaver = new PowerReceiver();

	
    @Override
    public void onCreate()
	{


		Log.i("HardwareService", "CRIANDO O SERVICO");
        super.onCreate();
 		settings = getSharedPreferences("pref", MODE_PRIVATE);
		SharedPreferences.Editor editor = settings.edit();
		editor.putString("ativado","on");
		editor.putBoolean("enabled", true);
		editor.putBoolean("lockscreen", true);
		editor.apply();
		
		notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		Intent ittSettings = new Intent();
        ittSettings.setComponent(new ComponentName("com.android.settings", CMP));
        PendingIntent pitSettings = PendingIntent.getActivity(this, 0, ittSettings, 0);
        notBuilder = new Notification.Builder(this);
		notBuilder.setColor(Color.rgb(244, 67, 54));
		this.notBuilder.setOnlyAlertOnce(true);
		this.notBuilder.setOngoing(true);
		//notBuilder.setShowWhen(true);
	
		if (Build.VERSION.SDK_INT >= 23)
		{
			notBuilder.setSmallIcon(R.drawable.wkb000);
			notBuilder.setColor(Color.TRANSPARENT);
		}
		else
		{
			notBuilder.setSmallIcon(R.drawable.wkb000);
		}

		
		notBuilder.setContentIntent(pitSettings);
		notBuilder.setPriority(Integer.MAX_VALUE);
        notBuilder.setCategory(NotificationCompat.CATEGORY_SERVICE);
		visibilityPublic(settings.getBoolean("lockscreen", true));
		Util.setSmallNotificationIcon(notBuilder);

		Log.d("HardwareService", "Setting up the service manager and the broadcast receiver");
        mgrConnectivity = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		mgrWireless = (WifiManager) getSystemService(Context.WIFI_SERVICE);
        mgrTelephony = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        hndNotifier = new NotificationHandler(getApplicationContext());

        if (settings.getBoolean("enabled", true))
		{
            Log.d("HardwareService", "Screen on; showing the notification");
            hndNotifier.sendEmptyMessage(1);}

        recScreen = new BroadcastReceiver() {			
			@Override
            public void onReceive(Context ctcContext, Intent ittIntent)
			{
				if (settings.getString("ativado", "").toString().equals((Object)"on"))
				{
					hideNotification();}
				else{

                if (ittIntent.getAction().equalsIgnoreCase(Intent.ACTION_SCREEN_OFF))
				{

                    Log.d("TrafficService", "Screen off; notificacao oculta");
                    hndNotifier.removeMessages(1);
                    notificationManager.cancel(ID);
                }
				else if (ittIntent.getAction().equalsIgnoreCase(Intent.ACTION_SCREEN_ON))
				{

                    Log.d("TrafficService", "Screen on; notificacao ativa");
                    connectivityUpdate();
                }
				else if (ittIntent.getAction().equalsIgnoreCase(Intent.ACTION_AIRPLANE_MODE_CHANGED))
				{

                    if (ittIntent.getBooleanExtra("state", false))
					{

                        Log.d("TrafficService", "Modo aviao, ocultando notificacao");
                        hndNotifier.removeMessages(1);
                        hndNotifier.sendEmptyMessage(1);
                    }
					else
					{

                        Log.d("TrafficService", "Modo aviao mostrando notificacao");
                        connectivityUpdate();
                    }
                }
				else
				{

                    Log.d("TrafficService", "Connectivity change; atualizando notificacao");
                    connectivityUpdate();

                }
            }}
        };

        IntentFilter ittScreen = new IntentFilter();
        ittScreen.addAction(Intent.ACTION_SCREEN_ON);
        ittScreen.addAction(Intent.ACTION_SCREEN_OFF);
        ittScreen.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        ittScreen.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(recScreen, ittScreen);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
		{
            IntentFilter ittSaver = new IntentFilter();
            ittScreen.addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED);
            registerReceiver(recSaver, ittSaver);
        }
    }
	
    private void connectivityUpdate()
	
{
	if (settings.getString("ativado", "").toString().equals((Object)"on"))
	{
		hideNotification();}
	else{
		NetworkInfo nifNetwork = mgrConnectivity.getActiveNetworkInfo();
        if (nifNetwork != null && nifNetwork.isConnectedOrConnecting())
		{

            Log.d("TrafficService", "Rede conectada mostrando notificacao");
            if (nifNetwork.getType() == ConnectivityManager.TYPE_WIFI)
			{

                Log.d("TrafficService", "Conectando rede Wiffi");
                WifiInfo wifInfo = mgrWireless.getConnectionInfo();
                if (wifInfo != null && !wifInfo.getSSID().trim().isEmpty())
				{

                    Log.d("TrafficService", wifInfo.getSSID());
                    notBuilder.setContentTitle(getString(R.string.wireless));
					notBuilder.setSubText(Util.getIpAddress());
                    notBuilder.setContentText(wifInfo.getSSID().replaceAll("^\"|\"$", ""));
                    showNotification();
                }
				else
				{

                    Log.d("TrafficService", "Unknown network without SSID");
                    hideNotification();
                }
            }
			else
			{

                Log.d("TrafficService", "Conectando dados moveis");
                if (!mgrTelephony.getNetworkOperatorName().trim().isEmpty())
				{

                    Log.d("TrafficService", mgrTelephony.getNetworkOperatorName());
                    notBuilder.setContentTitle(getString(R.string.cellular));
					notBuilder.setSubText(Util.getIpAddress());
					 notBuilder.setContentText(mgrTelephony.getNetworkOperatorName());
                    showNotification();
                }
				else
				{

                    Log.d("TrafficService", "Unknown network without IMSI");
                    hideNotification();
                }
            }
        }
		else
		{

            Log.d("TrafficService", "Rede desconectada notificacao oculta");
            hideNotification();
        }
	}}

    @Override
    public void onDestroy()
	{

        Log.d("HardwareService", "Parando servico");
        unregisterReceiver(recScreen);
        unregisterReceiver(recSaver);
        hndNotifier.removeMessages(1);
        notificationManager.cancel(ID);

    }


    public void showNotification()
	{

        Log.d("HardwareService", "Showc notificacao");
        notificationManager.notify(ID, notBuilder.build());
        hndNotifier.removeMessages(1);
        hndNotifier.sendEmptyMessage(1);
    }


    public void hideNotification()
	{

        Log.d("HardwareService", "ocultandocnotificacao");
        notificationManager.cancel(ID);
        hndNotifier.removeMessages(1);
    }


    public void visibilityPublic(Boolean visibility)
	{
        if (visibility)
		{
            notBuilder.setVisibility(NotificationCompat.VISIBILITY_PUBLIC);
        }
		else
		{
            notBuilder.setVisibility(NotificationCompat.VISIBILITY_SECRET);
        }
    }


    public void setColor(Integer color)
	{
        notBuilder.setColor(color);
    }

    @Override
    public IBinder onBind(Intent intReason)
	{
        return mBinder;
    }

    private static class NotificationHandler extends Handler
	{

        private final Context ctxContext;

        private long lngPrevious = 0L;

        @SuppressLint("CommitPrefEdits")
        public NotificationHandler(Context ctxContext)
		{
            this.ctxContext = ctxContext;
        }

        @Override
        public void handleMessage(Message msgMessage)
		{

            TrafficService.hndNotifier.sendEmptyMessageDelayed(1, 1000L);

            long lngCurrent = TrafficStats.getTotalRxBytes() + TrafficStats.getTotalTxBytes();
            int lngSpeed = (int) (lngCurrent - lngPrevious);
            lngPrevious = lngCurrent;

            try
			{

                if (lngSpeed < 1024)
				{
                    TrafficService.notBuilder.setSmallIcon(R.drawable.wkb000);
                    updateIcon(R.drawable.wkb000);
                }
				else if (lngSpeed < 1048576L)
				{

                    TrafficService.notBuilder.setSmallIcon(R.drawable.wkb000 + (int) (lngSpeed / 1024L));
                    updateIcon(R.drawable.wkb000 + (int) (lngSpeed / 1024L));
                    if (lngSpeed > 1022976)
					{
                        TrafficService.notBuilder.setSmallIcon(R.drawable.wkb000 + 1000);
                        updateIcon(R.drawable.wkb000 + 1000);
                    }
                }
				else if (lngSpeed <= 10485760)
				{
                    TrafficService.notBuilder.setSmallIcon(990 + R.drawable.wkb000
														   + (int) (0.5D + (double) (10F * ((float) lngSpeed / 1048576F))));
                    updateIcon(990 + R.drawable.wkb000
							   + (int) (0.5D + (double) (10F * ((float) lngSpeed / 1048576F))));
                }
				else if (lngSpeed <= 103809024)
				{
                    TrafficService.notBuilder.setSmallIcon(1080 + R.drawable.wkb000
														   + (int) (0.5D + (double) ((float) lngSpeed / 1048576F)));
                    updateIcon(1080 + R.drawable.wkb000
							   + (int) (0.5D + (double) ((float) lngSpeed / 1048576F)));
                }
				else
				{
                    TrafficService.notBuilder.setSmallIcon(1180 + R.drawable.wkb000);
                    updateIcon(1180 + R.drawable.wkb000);
                }

                Long lngTotal = TrafficStats.getTotalRxBytes() + TrafficStats.getTotalTxBytes();
                String strTotal = Formatter.formatFileSize(this.ctxContext, lngTotal);
                TrafficService.notBuilder.setContentInfo(strTotal);
                TrafficService.notificationManager.notify(ID, TrafficService.notBuilder.build());
            }
			catch (Exception e)
			{
                Log.e("NotificationHandler", "Error creating notification for speed " + lngSpeed);
            }
        }

        private void updateIcon(int value)
		{
            if (Build.VERSION.SDK_INT != Build.VERSION_CODES.N)
			{
                return;
            }
            Bitmap bmpIcon = BitmapFactory.decodeResource(this.ctxContext.getResources(), value);
            TrafficService.notBuilder.setLargeIcon(bmpIcon);
        }
    }

    public class LocalBinder extends Binder
	{

        public TrafficService getServerInstance()
		{
            return TrafficService.this;
        }
    }
}

package net.agn.vpn.core;

import android.content.Context;
import android.net.Uri;
import com.trilead.ssh2.sftp.AttribFlags;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

public class VpnProfile {
    private static VpnProfile instance;
    private Context context;
    private JSONObject js;
    public ArrayList<String> listBlocks = new ArrayList();

    public VpnProfile(Context context) {
        this.context = context;
        try {
            File file = new File(context.getFilesDir(), "profile.sic");
            if (file.exists()) {
                this.js = new JSONObject(readFile(file));
            }
        } catch (Exception e) {
        }
    }

    public static VpnProfile getProfile(Context context) {
        if (instance == null) {
            instance = new VpnProfile(context);
        }
        return instance;
    }

    public void setConfig(String str) {
        try {
            this.js = new JSONObject(str);
        } catch (Exception e) {
        }
    }

    public void save() {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(new File(this.context.getFilesDir(), "profile.sic"));
            fileOutputStream.write(this.js.toString(2).getBytes());
            fileOutputStream.flush();
            fileOutputStream.close();
        } catch (Exception e) {
        }
    }

    public void clear() {
        if (isProfileExists()) {
            new File(this.context.getFilesDir(), "profile.sic").delete();
        }
    }

    public String getSSHHost() throws JSONException {
        return this.js.getString("SSH Host");
    }

    public int getSSHPort() throws JSONException {
        return Integer.parseInt(this.js.getString("SSH Port"));
    }

    public String getUsername() throws JSONException {
        return this.js.getString("Username");
    }

    public String getPassword() throws JSONException {
        return this.js.getString("Password");
    }

    public String getPayload() throws JSONException {
        return this.js.getString("Payload");
    }

    public String getProxy() throws JSONException {
        return this.js.getString("Proxy");
    }

    public int getProxyPort() throws JSONException {
        return Integer.parseInt(this.js.getString("ProxyPort"));
    }

    public String getInfo() throws JSONException {
        if (this.js.has("Message")) {
            return this.js.getString("Message");
        }
        return "";
    }

    public boolean getAntiTorrentEnabled() throws JSONException {
        if (isProfileExists() && this.js.getBoolean("AntiTorrent")) {
            return true;
        }
        return false;
    }

    public boolean isProfileExists() {
        return new File(this.context.getFilesDir(), "profile.sic").exists();
    }

    public boolean isLocked() {
        try {
            if (isProfileExists() && this.js.getBoolean("Locked")) {
                return true;
            }
        } catch (JSONException e) {
        }
        return false;
    }

    public boolean getProxyAuthEnabled() throws JSONException {
        return this.js.getBoolean("ProxyAuth");
    }

    public String getProxyUsername() throws JSONException {
        return this.js.getString("ProxyUser");
    }

    public String getProxyPassword() throws JSONException {
        return this.js.getString("ProxyPass");
    }

    public void setProxyAuthEnabled(boolean z) throws JSONException {
        this.js.put("ProxyAuth", z);
    }

    public void setProxyPassword(String str) throws JSONException {
        this.js.put("ProxyPass", str);
    }

    public void setProxyUsername(String str) throws JSONException {
        this.js.put("ProxyUser", str);
    }

    public void setPayload(String str) throws JSONException {
        this.js.put("Payload", str);
    }

    public void setProxy(String str) throws JSONException {
        this.js.put("Proxy", str);
    }

    public void setProxyPort(String str) throws JSONException {
        this.js.put("ProxyPort", str);
    }

    public void setSSHHost(String str) throws JSONException {
        this.js.put("SSH Host", str);
    }

    public void setSSHPort(String str) throws JSONException {
        this.js.put("SSH Port", str);
    }

    public void setUsername(String str) throws JSONException {
        this.js.put("Username", str);
    }

    public void setPassword(String str) throws JSONException {
        this.js.put("Password", str);
    }

    public String readFile(Object obj) {
        StringBuilder stringBuilder = new StringBuilder();
        try {
            InputStream fileInputStream;
            InputStream inputStream = (InputStream) null;
            if (obj instanceof File) {
                fileInputStream = new FileInputStream((File) obj);
            } else if (obj instanceof String) {
                fileInputStream = new FileInputStream(new File((String) obj));
            } else if (obj instanceof InputStream) {
                fileInputStream = (InputStream) obj;
            } else if (obj instanceof Uri) {
                fileInputStream = this.context.getContentResolver().openInputStream((Uri) obj);
            } else {
                fileInputStream = inputStream;
            }
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
            char[] cArr = new char[AttribFlags.SSH_FILEXFER_ATTR_MIME_TYPE];
            while (true) {
                int read = bufferedReader.read(cArr);
                if (read <= 0) {
                    break;
                }
                stringBuilder.append(cArr, 0, read);
            }
        } catch (Exception e) {
        }
        return stringBuilder.toString();
    }
}


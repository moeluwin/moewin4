package net.agn.vpn;

import android.os.*;

import androidx.appcompat.app.*;
import android.widget.*;
import android.widget.LinearLayout.*;

import com.google.android.material.appbar.AppBarLayout;

import net.agn.vpn.view.CenteredToolBar;
public class ExceptionActivity extends AppCompatActivity {
    TextView error;
    private CenteredToolBar toolbar;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
        layoutParams.gravity = 17;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setLayoutParams(layoutParams);
        setContentView(linearLayout);
        AppBarLayout abl = new AppBarLayout(this);
		toolbar = new CenteredToolBar(this);
        setSupportActionBar(this.toolbar);
        toolbar.setTitle("Application Error");
		
        abl.addView(toolbar);
		ScrollView sv = new ScrollView(this);
        TextView error = new TextView(this);
        sv.addView(error);
        linearLayout.addView(abl);
        linearLayout.addView(sv);
        error.setText(getIntent().getStringExtra("error"));
    }
}






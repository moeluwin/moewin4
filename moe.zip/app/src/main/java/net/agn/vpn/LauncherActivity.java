package net.agn.vpn;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import net.agn.vpn.MainBase;

/**
 * @author anuragdhunna
 */
public class LauncherActivity extends MainBase
{
	
	private TextView app_name;
	
	private Animation txtAnim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash_screen);
	
		app_name=(TextView)findViewById(R.id.app_name);

		app_name.setVisibility(View.VISIBLE);

		final Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
                @Override
                public void run() {
					// inicia atividade principal
					Intent intent = new Intent(getApplicationContext(), MainActivity.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
					startActivity(intent);

					// encerra o launcher
					finish();
                }
            }, 3000);
    }
	
}

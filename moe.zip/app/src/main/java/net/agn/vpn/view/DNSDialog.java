package net.agn.vpn.view;
import android.content.Context;
import androidx.appcompat.app.AlertDialog;
import android.widget.EditText;
import android.content.DialogInterface;
import com.google.android.material.textfield.TextInputLayout;
import android.content.SharedPreferences;
import net.agn.vpn.TcodesApplication;

public class DNSDialog
{

    private AlertDialog.Builder adb;

    public DNSDialog(Context context)
    {
	    final SharedPreferences sp = TcodesApplication.getSharedPreferences();
        TextInputLayout til = new TextInputLayout(context);
		final EditText edt = new EditText(context) ;
        edt.setHint("e.g 1.1.1.1:8.8.8.8");
		edt.setText(sp.getString("dns_forward", "8.8.8.8;8.8.4.4"));
		til.addView(edt);
        adb = new AlertDialog.Builder(context);
        adb.setCancelable(false);
		adb.setTitle("DNS FORWARDER");
        //adb.setMessage("Select VPN Mode");
        adb.setView(til, 40, 0, 40, 0);
        adb.setPositiveButton("SAVE", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
				{
                    sp.edit().putString("dns_forward", edt.getText().toString()).commit();
					// sp.edit().putString("", userP.getText().toString()).commit();
                }
			});
        adb.setNegativeButton("CANCEL", null);
    }

    public void show()
    {
        adb.create().show();
    }
}

package net.agn.vpn;
import android.annotation.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import androidx.appcompat.app.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.util.concurrent.atomic.*;

import net.agn.vpn.util.*;
import net.agn.vpn.view.*;

public class AboutActivity extends AppCompatActivity
{

    private LayoutInflater layoutInflater;

    private AutoFitGridLayout vLinks;

    private TextView appName;

    private TextView appVersion;

    private TextView appLastUpdate;

    private TextView appDevText;

    private ImageView appDevIcon;

    private Constants conts;

    public final class Item
	{

        private int id;
        private String label;
        private int icon;
        private View.OnClickListener onClick;

        public String getLabel()
		{
            return label;
        }

        public void setLabel(String label)
		{
            this.label = label;
        }

        public int getIcon()
		{
            return icon;
        }

        public void setIcon(int icon)
		{
            this.icon = icon;
        }

        public View.OnClickListener getOnClick()
		{
            return onClick;
        }

        public void setOnClick(View.OnClickListener onClick)
		{
            this.onClick = onClick;
        }

        public int getId()
		{
            return id;
        }

        public Item(int icon, String label, View.OnClickListener onClick)
		{
            this.id = ViewIdGenerator.generateViewId();
            this.label = label;
            this.icon = icon;
            this.onClick = onClick;
        }
    }

    public static class ViewIdGenerator
	{
        private static final AtomicInteger sNextGeneratedId = new AtomicInteger(1);

        @SuppressLint("NewApi")
        public static int generateViewId()
		{

            if (Build.VERSION.SDK_INT < 17)
			{
                for (;;)
				{
                    final int result = sNextGeneratedId.get();
                    // aapt-generated IDs have the high byte nonzero; clamp to the range under that.
                    int newValue = result + 1;
                    if (newValue > 0x00FFFFFF)
                        newValue = 1; // Roll over to 1, not 0.
                    if (sNextGeneratedId.compareAndSet(result, newValue))
					{
                        return result;
                    }
                }
            }
			else
			{
                return View.generateViewId();
            }

        }
    }

    @SuppressWarnings("ConstantConditions")
    private void setupToolbar(String title)
    {
        CenteredToolBar toolbar = (CenteredToolBar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (title != null)
        {
            getSupportActionBar().setTitle(title);
        }
        else
        {
            ActivityInfo activityInfo;
            try
            {
                activityInfo = getPackageManager().getActivityInfo(getComponentName(), PackageManager.GET_META_DATA);
                String currentTitle = activityInfo.loadLabel(getPackageManager()).toString();
                getSupportActionBar().setTitle(currentTitle);

            }
            catch (PackageManager.NameNotFoundException ignored)
            {

            }

        }
        //getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_burger);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        layoutInflater = LayoutInflater.from(this);
        setContentView(R.layout.activity_about);
        setupToolbar("About");
        //animateReavel();
        conts = new Constants(this);
        appName = (TextView) findViewById(R.id.aboutAppName);
        appName.setText(getString(R.string.app_name));
        appVersion = (TextView) findViewById(R.id.aboutVersion);
        appVersion.setText(Util.vb(this));
        appLastUpdate = (TextView) findViewById(R.id.aboutLastUpdate);
        appLastUpdate.setText(conts.getConfigVersion());
        appDevIcon = (ImageView) findViewById(R.id.aboutDevIcon);
        appDevIcon.setImageResource(R.drawable.magicph_icon);
        appDevText = (TextView) findViewById(R.id.aboutDevText);
        appDevText.setText("Khaled AGN");
        vLinks = (AutoFitGridLayout) findViewById(R.id.aboutAppGrid);
        vLinks.setColumnCount(3);
        addItem(vLinks, new Item(R.drawable.instagram, "Instagram", new OnClickListener() {
                        @Override
                        public void onClick(View p1)
                        {
							Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("https://www.instagram.com/khaledagn"));
							startActivity(intent);
                        }
                    }));
        addItem(vLinks, new Item(R.drawable.telegram, "Telegram Channel", new OnClickListener() {
                        @Override
                        public void onClick(View p1)
                        {
							Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("https://twitter.com/khaled_agn"));
							startActivity(intent);
                        }
                    }));
        addItem(vLinks, new Item(R.drawable.youtube, "Youtube channel", new OnClickListener() {
            @Override
            public void onClick(View p1)
            {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("https://www.youtube.com/channel/UCA2FDRkzRSf5xRpm8nRt7_A"));
                startActivity(intent);
            }
        }));


					}

    private View addItem(ViewGroup holder,  Item item)
	{
        View view = layoutInflater.inflate(R.layout.about_link_item, null);
        view.setId(item.getId());

        TextView tvLabel = (TextView) view.findViewById(R.id.label);
        ImageView ivIcon = (ImageView) view.findViewById(R.id.icon);

        Icon.on(ivIcon).icon(item.getIcon()).color(Color.parseColor(getString(R.color.colorPrimaryDark))).put();

        tvLabel.setText(item.getLabel());
        view.setOnClickListener(item.getOnClick());

		// RippleUtil.backgroundRipple(view, getCardColor());

        holder.addView(view);
        return view;
    }



}

package net.agn.vpn.core;

import android.annotation.SuppressLint;
import android.net.VpnService;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.nio.channels.SocketChannel;
import java.security.Security;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import net.agn.vpn.InjectorService;
import net.agn.vpn.util.Constants;
import org.conscrypt.Conscrypt;


public class HttpRequest extends Thread 
{

	static {
        try
		{
            Security.insertProviderAt(Conscrypt.newProvider(), 1);

        }
		catch (NoClassDefFoundError e)
		{
            e.printStackTrace();
        }}


	public boolean isAlive = true;
	public static final String SEND_BUFF = "16384";
	public static final String RECV_BUFF = "32768";
	private static InjectorService service;
	private Constants constants;
	private ServerSocket ss;
	private static Socket client;
	public static Socket server;
	volatile SSLSocket b;
    private int repeatCount = 0;
	private HttpsURLConnection u;
	private SSLAddress v;
	public HttpRequest(InjectorService service)
	{
		this.service = service;
		constants = service.constant;
	}

	@Override
	public void run()
	{
		try
        {
			ss = new ServerSocket(constants.getLocalPort());
	     	service.log("Listening for incominng connection");
			service.handler.sendEmptyMessage(InjectorService.START_SSH);
		}
        catch (Exception e)
        {
			log(e.getClass().getSimpleName(), e);
		}
		try
        {
			if (constants.isSSL())
			{
				if (this.v != null)
				{
					this.v.b();
				}
				this.v = new SSLAddress();
				this.v.start();
			}
			while (isAlive)
            {
				client = ss.accept();
				if (client != null && !client.isClosed() && connectProxy())
                {
					client.setKeepAlive(true);
					if (server != null && server.isConnected())
                    {
						server.setKeepAlive(true);
						try
                        {
							ProxyThread.connect(service, client, server, SEND_BUFF, RECV_BUFF, false);
						}
                        catch (Exception e)
                        {
							log(e.getClass().getSimpleName(), e);
						}
					}
				}
			}
		}
        catch (Exception e)
        {
			log(e.getClass().getSimpleName(), e);
		}
		super.run();
	}

	private boolean connectProxy()
	{
		try
        {
            if (constants.isSSL())
            {
                String readRequestHeader = readRequestHeader();
                if (readRequestHeader == null || !readRequestHeader.contains(":"))
                {
                    log(new StringBuffer().append("Invalid request: ").append(readRequestHeader).toString());
                    return false;
                }
                String host = readRequestHeader.split(":")[0];
                int port = Integer.parseInt(readRequestHeader.split(":")[1]);
                sendForwardSuccess(client);
                server = SocketChannel.open().socket();
                server.connect(new InetSocketAddress(host, port));
                if (server.isConnected())
                {
					//server = a(constants.getSSHHost(), constants.getSSLPort());
                    server = doSSLHandshakeOld(constants.getSSHHost(), constants.getPayload(), constants.getSSLPort());
                }
            }
            else
            {
                String proxy = constants.getProxy();
                int proxyPort = constants.getProxyPort();
                String payload = constants.getPayload();
                /*InetSocketAddress addr = new InetSocketAddress(proxy, proxyPort);
                 //log("Connecting to Proxy - " + addr.getHostString() + ":" + addr.getPort());
                 server = new Socket();
                 server.setTcpNoDelay(true);
                 server.connect(addr);

                 //log("Sending Request: " + payload);
                 try
                 {
                 log("Requesting");
                 inject(payload, client.getInputStream(), server.getOutputStream());
                 }
                 catch (Exception e)
                 {
                 log("Request Response", e);
                 }*/
                server = inject(payload, proxy, proxyPort);
            }
			return !client.isClosed() && server.isConnected();
		}
        catch (Exception e)
        {
			log("Proxy Socket", e);
			return false;
		}
	}

    private String readRequestHeader() throws IOException
    {
        Reader reader = new InputStreamReader(client.getInputStream());
        BufferedReader lineReader = new BufferedReader(reader);
        String request = null;
        String line;
        while ((line = lineReader.readLine()) != null)
        {
            if (line.startsWith("CONNECT") && request == null)
            {
                request = line.split(" ")[1];
            }
            if (line.length() == 0)
            {
                return request;
            }
        }
        return request;
    }

    private void sendForwardSuccess(Socket socket) throws IOException
    {
        String respond = "HTTP/1.1 200 OK\r\n\r\n";
        socket.getOutputStream().write(respond.getBytes());
        socket.getOutputStream().flush();
    }


    public static boolean a(VpnService vpnService)
    {
        if (server == null)
        {
            //log("Socket is null");
            return false;
        }
        else if (server.isClosed())
        {
            //log("Socket is closed");
            return false;
        }
        else if (!server.isConnected())
        {
            //log("Socket not connected");
            return false;
        }
        else if (vpnService.protect(server))
        {
            //log("Socket has protected");
            return true;
        }
        else
        {
            //log("Failed to protecting socket, reboot this device required");
            return false;
        }
	}

	public static boolean b(VpnService vpnService)
    {
        if (client == null)
        {
            //log("Socket is null");
            return false;
        }
        else if (client.isClosed())
        {
            //log("Socket is closed");
            return false;
        }
        else if (!client.isConnected())
        {
            //log("Socket not connected");
            return false;
        }
        else if (vpnService.protect(client))
        {
            //log("Socket has protected");
            return true;
        }
        else
        {
            //log("Failed to protecting socket, reboot this device required");
            return false;
        }
	}



	private Socket doSSLHandshakeOld(String host, String sni, int port) throws IOException
    {


		TrustManager[] trustAllCerts = new TrustManager[] {
            new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers()
                {
                    return null;
                }
                public void checkClientTrusted(
                    java.security.cert.X509Certificate[] certs, String authType)
                {
                }
                public void checkServerTrusted(
                    java.security.cert.X509Certificate[] certs, String authType)
                {
                }
            }
        };
        try
        {
			boolean secureRandom = true;

            SSLContext sSLContext =SSLContext.getInstance("TLS", "Conscrypt");
			// KeyManager[] keyManagerArr = (KeyManager[]) null;

			X509TrustManager tm = Conscrypt.getDefaultX509TrustManager();
			SSLContext sslContext = SSLContext.getInstance("TLS", "Conscrypt");
			sslContext.init(null, new TrustManager[] { tm }, null);

			SSLSocket socket = (SSLSocket) sslContext.getSocketFactory().createSocket(server, host, port, true);
			setSNIHost(sslContext.getSocketFactory(), socket, sni);
			socket.setEnabledProtocols(new String[] {"TLSv1", "TLSv1.1", "TLSv1.2", "TLSv1.3"});


			//sSLContext.init(keyManagerArr, trustAllCerts, secureRandom ? new SecureRandom() : null);
			//SSLSocket socket = (SSLSocket) sSLContext.getSocketFactory().createSocket(server, host, port, true);
            //setSNIHost(sSLContext.getSocketFactory(), socket, sni);
			//socket.setEnabledProtocols(socket.getEnabledProtocols());
			//socket.addHandshakeCompletedListener(new mHandshakeCompletedListener(host, port, socket));
            //socket.startHandshake();

			URL url = new URL("https://" + sni);
			String d = url.getHost();
            if (url.getPort() > 0)
			{
                d = d + ":" + url.getPort();
            }
            if (!url.getPath().equals("/"))
			{
                d = d + url.getPath();
            }
			log(d);
			if (secureRandom)
			{
				this.u = (HttpsURLConnection) url.openConnection(new Proxy(Type.HTTP, this.v.a()));
			}
			else
			{
				this.u = (HttpsURLConnection) url.openConnection();
			}
			this.u.setHostnameVerifier(new HostnameVerifier() {
					@SuppressLint({"BadHostnameVerifier"})
					public boolean verify(String str, SSLSession sSLSession)
					{
						return true;
					}
				});
			this.u.setSSLSocketFactory(sSLContext.getSocketFactory());
			this.u.connect();

            /*SSLSession session = socket.getSession();

			 try
			 {
			 d = session.getPeerPrincipal().toString();
			 }
			 catch (Exception e)
			 {
			 d = "None";
			 }
			 log(a2 + session.getCipherSuite() + session.getProtocol() + d);*/

            return socket;
        }
        catch (Exception e)
        {
            IOException iOException = new IOException(new StringBuffer().append("Could not do SSL handshake: ").append(e).toString());
            throw iOException;
        }
    }

    private void setSNIHost(final SSLSocketFactory factory, final SSLSocket socket, final String hostname)
    {
        if (factory instanceof android.net.SSLCertificateSocketFactory && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1)
        {
            ((android.net.SSLCertificateSocketFactory)factory).setHostname(socket, hostname);
        }
        else
        {
            try
            {
                socket.getClass().getMethod("setHostname", String.class).invoke(socket, hostname);
            }
            catch (Throwable e)
            {
                // ignore any error, we just can't set the hostname...
            }
        }
    }

    private void a(String str, Socket socket) throws Exception
    {
        String[] split;
        int i = 0;
        OutputStream outputStream = socket.getOutputStream();
        if (str.contains("[random]"))
        {
            Random random = new Random();
            String[] split2 = str.split(Pattern.quote("[random]"));
            str = split2[random.nextInt(split2.length)];
        }
        if (str.contains("[repeat]"))
        {
            split = str.split(Pattern.quote("[repeat]"));
            str = split[this.repeatCount];
            this.repeatCount++;
            if (this.repeatCount > split.length - 1)
            {
                this.repeatCount = 0;
            }
        }
        /* String replace = str.replace("\r\n", "\\r\\n");
         StringBuffer append = new StringBuffer().append("Payload: ");
         log(append.append(replace).toString());
         log("Injecting");*/
        int length;
        String str2;
        if (str.contains("[delay_split]"))
        {
            split = str.split(Pattern.quote("[delay_split]"));
            length = split.length;
            while (i < length)
            {
                str2 = split[i];
                if (a(str2, socket, outputStream))
                {
                    outputStream.write(str2.getBytes());
                    outputStream.flush();
                    Thread.sleep((long) 1500);
                }
                i++;
            }
        }
        else if (str.contains("[instant_split]"))
        {
            split = str.split(Pattern.quote("[instant_split]"));
            length = split.length;
            while (i < length)
            {
                str2 = split[i];
                if (a(str2, socket, outputStream))
                {
                    outputStream.write(str2.getBytes());
                    outputStream.flush();
                    Thread.sleep((long) 100);
                }
                i++;
            }
        }
        else if (str.contains("[split_delay]"))
        {
            for (String str3 : str.split(Pattern.quote("[split_delay]")))
            {
                if (a(str3, socket, outputStream))
                {
                    outputStream.write(str3.getBytes());
                    outputStream.flush();
                    Thread.sleep((long) 1500);
                }
            }
        }
        else if (str.contains("[split]"))
        {
            for (String strko: str.split(Pattern.quote("[split]")))
            {
                outputStream.write(strko.getBytes());
                outputStream.flush();
			}
        }
        else
        {
            outputStream.write(str.getBytes());
			outputStream.flush();
        }
    }

	private void inject(String payload, InputStream input, OutputStream outputStream) throws Exception
	{
		String ssh = getConnectionServer(input);
		String request = payload.replace("[host_port]", ssh).replace("[protocol]", "HTTP/1.0").replace("[crlf]", "\r\n").replace("[cr]", "\r").replace("[lf]", "\n");
		//log("Sending Request: " + request);
        if (request.contains("[delay_split]"))
        {
            String[] split = request.split(Pattern.quote("[delay_split]"));
			for (String str: split)
            {
				outputStream.write(str.getBytes());
				outputStream.flush();
				sleep(1500);
			}
        }
        else if (request.contains("[split]"))
        {
			for (String str2: request.split(Pattern.quote("[split]")))
            {
				outputStream.write(str2.getBytes());
				outputStream.flush();
			}
		}
        else
        {
			outputStream.write(request.getBytes());
			outputStream.flush();
		}
		// TODO: Implement this method
	}

    private Socket inject(String payload, String proxy, int port)
    {
        try
        {
            String string2;
            BufferedReader bufferedReader = new BufferedReader((Reader)new InputStreamReader(this.client.getInputStream()));
            StringBuffer stringBuffer = new StringBuffer("");
            while ((string2 = bufferedReader.readLine()) != null && string2.length() > 0)
            {
                stringBuffer.append(string2);
                stringBuffer.append("\r\n");
            }
            if (stringBuffer.toString().equals((Object)""))
            {
                log("Get request data failed, empty requestline");
                return null;
            }
            String string3 = this.c(payload, stringBuffer.toString());
            if (string3 == null)
            {
                return null;
            }
            /*String string4 = new StringBuffer().append(new StringBuffer().append(proxy).append(":").toString()).append(port).toString();
             StringBuffer stringBuffer2 = new StringBuffer().append("Connecting to ");
             this.log("Socket Server" + stringBuffer2.append(string4).toString());*/
            Socket socket = new Socket();
            socket.setTcpNoDelay(true);
            socket.connect(new InetSocketAddress(proxy, port));
            if (string3.equals(""))
            {
                return socket;
            }
            a(string3, socket);
            return socket;
        }
        catch (Exception exception)
        {
            this.log("Socket Server" + exception.toString());
            return null;
        }
    }

	private String getConnectionServer(InputStream stream) throws IOException
	{
		BufferedReader in = new BufferedReader(new InputStreamReader(stream));
		String inputLine;
		int cnt = 0;
		String url = null;

		while ((inputLine = in.readLine()) != null)
        {
			try
            {
				StringTokenizer tok = new StringTokenizer(inputLine);
				tok.nextToken();
			}
            catch (Exception e)
            {
				break;
			}
			if (cnt == 0)
            {
				String[] tokens = inputLine.split(" ");
				url = tokens[1];

			}
			cnt++;
		}
		return url;
	}

    private boolean a(String str, Socket socket, OutputStream outputStream) throws Exception
    {
        if (!str.contains("[split]"))
        {
            return true;
        }
        String[] split = str.split(Pattern.quote("[split]"));
        for (String bytes : split)
        {
            outputStream.write(bytes.getBytes());
            outputStream.flush();
        }
        return false;
    }

    private String c(String payload, String str)
    {
        String str2 = null;
        if (str != null)
        {
            try
            {
                if (!str.equals(""))
                {
                    String str3 = str.split("\r\n")[0];
                    String[] split = str3.split(" ");
                    String[] split2 = split[1].split(":");
                    CharSequence charSequence = split2[0];
                    CharSequence charSequence2 = split2[1];               
                    //if (!this.isProxyAuthEnabled) {
                    return d(payload.replace("[real_raw]", str).replace("[raw]", str3).replace("[method]", split[0]).replace("[host_port]", split[1]).replace("[host]", charSequence).replace("[port]", charSequence2).replace("[protocol]", split[2]).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr]", "\n\r").replace("\\r", "\r").replace("\\n", "\n"));
                    //}
                    //return d(this.payload.replace("[real_raw]", str).replace("[raw]", str3).replace("[method]", split[0]).replace("[host_port]", split[1]).replace("[host]", charSequence).replace("[port]", charSequence2).replace("[protocol]", split[2]).replace("[auth]", new StringBuffer().append(android.util.Base64.encode(new StringBuffer().append(new StringBuffer().append(this.proxy_user).append(":").toString()).append(this.proxy_pass).toString().getBytes(StandardCharsets.ISO_8859_1))).toString()).replace("[cr]", "\r").replace("[lf]", "\n").replace("[crlf]", "\r\n").replace("[lfcr]", "\n\r").replace("\\r", "\r").replace("\\n", "\n"));
                }
            }
            catch (Exception e)
            {
                log("Payload Error");
            }
        }
        log("Payload is null or empty");
        return str2;
    }

    private String d(String str)
    {
        if (str.contains("[cr*"))
        {
            str = a(str, "[cr*", "\r");
        }
        if (str.contains("[lf*"))
        {
            str = a(str, "[lf*", "\n");
        }
        if (str.contains("[crlf*"))
        {
            str = a(str, "[crlf*", "\r\n");
        }
        return str.contains("[lfcr*") ? a(str, "[lfcr*", "\n\r") : str;
    }

    private String a(String str, String str2, String str3)
    {
        while (str.contains(str2))
        {
            Matcher matcher = Pattern.compile("\\[.*?\\*(.*?[0-9])\\]").matcher(str);
            if (matcher.find())
            {
                int intValue = Integer.valueOf(matcher.group(1)).intValue();
                String obj = "";
                for (int i = 0; i < intValue; i++)
                {
                    obj = new StringBuffer().append(obj).append(str3).toString();
                }
                str = str.replace(new StringBuffer().append(str2).append(String.valueOf(intValue)).append("]").toString(), obj);
            }
        }
        return str;
    }

	public void Stop() 
	{
        repeatCount = 0;
		isAlive = false;
        try
        {
			if (this.v != null)
			{
				this.v.b();
				this.v = null;
			}

            if (ss != null)
            {
                ss.close();
            }
			try
			{
				this.b.close();
			}
			catch (Exception e2)
			{
			}
			try
			{
				this.u.disconnect();
			}
			catch (Exception e3)
			{
			}
            if (client != null)
            {
                client.close();
            }
            if (server != null)
            {
                server.close();
            }
        }
        catch (Exception e)
        {
            log(e.getMessage());
        }
	}

	public static void log(String tag, Exception e)
    {
		service.log(String.format("%s: %s", tag, e.getMessage()));
	}

	public static void log(String msg)
	{
		service.log(msg);
	}
}

package net.agn.vpn.fragment;
import android.content.*;
import android.os.*;
import android.preference.*;
import net.agn.vpn.*;

public class SettingFragment extends PreferenceFragment implements SharedPreferences.OnSharedPreferenceChangeListener
{

	@Override
	public void onSharedPreferenceChanged(SharedPreferences p1, String p2)
	{

	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		addPreferencesFromResource(R.xml.ssh_preference);
	}
}

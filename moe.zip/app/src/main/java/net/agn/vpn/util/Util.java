package net.agn.vpn.util;


import android.app.Application;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.graphics.drawable.Icon;
import android.os.Build;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.apache.http.conn.util.InetAddressUtils;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import android.view.View;
import android.graphics.drawable.Drawable;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.view.MenuItem;
import androidx.appcompat.view.menu.MenuItemImpl;
import java.lang.reflect.Field;
import androidx.appcompat.view.menu.MenuBuilder;
import android.content.pm.ApplicationInfo;

public class Util
{
    
    private static final String APP_CLONER_NOTIFICATION_CHANNEL_ID = "AppCloner";
    private static final String APP_CLONER_NOTIFICATION_CHANNEL_ID_HIGH_IMPORTANCE = "AppClonerHighImportance";
    private static final String APP_CLONER_NOTIFICATION_CHANNEL_NAME = "App Cloner";
    private static final String APP_CLONER_NOTIFICATION_CHANNEL_NAME_HIGH_IMPORTANCE = "App Cloner High Importance";
    private static Application sApplication;
    private static boolean sNotificationChannelCreated;
    private static boolean sNotificationChannelCreatedHighImportance;
    private static Icon sNotificationIcon;

    private static final String CANDIDATE_10_SLASH_8 = "10.0.0.1";
    private static final String SUBNET_10_SLASH_8 = "10.0.0.0";
    private static final int PREFIX_LENGTH_10_SLASH_8 = 8;
    private static final String ROUTER_10_SLASH_8 = "10.0.0.2";

    private static final String CANDIDATE_172_16_SLASH_12 = "172.16.0.1";
    private static final String SUBNET_172_16_SLASH_12 = "172.16.0.0";
    private static final int PREFIX_LENGTH_172_16_SLASH_12 = 12;
    private static final String ROUTER_172_16_SLASH_12 = "172.16.0.2";

    private static final String CANDIDATE_192_168_SLASH_16 = "192.168.0.1";        
    private static final String SUBNET_192_168_SLASH_16 = "192.168.0.0";
    private static final int PREFIX_LENGTH_192_168_SLASH_16 = 16;
    private static final String ROUTER_192_168_SLASH_16 = "192.168.0.2";

    private static final String CANDIDATE_169_254_1_SLASH_24 = "169.254.1.1";        
    private static final String SUBNET_169_254_1_SLASH_24 = "169.254.1.0";
    private static final int PREFIX_LENGTH_169_254_1_SLASH_24 = 24;
    private static final String ROUTER_169_254_1_SLASH_24 = "169.254.1.2";

    public static String selectPrivateAddress()
    {
        // Select one of 10.0.0.1, 172.16.0.1, or 192.168.0.1 depending on
        // which private address range isn't in use.

        ArrayList<String> candidates = new ArrayList<String>();
        candidates.add(CANDIDATE_10_SLASH_8);
        candidates.add(CANDIDATE_172_16_SLASH_12);
        candidates.add(CANDIDATE_192_168_SLASH_16);
        candidates.add(CANDIDATE_169_254_1_SLASH_24);

        List<NetworkInterface> netInterfaces;
        try
        {
            netInterfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
        }
        catch (SocketException e)
        {
            return null;
        }

        for (NetworkInterface netInterface : netInterfaces)
        {
            for (InetAddress inetAddress : Collections.list(netInterface.getInetAddresses()))
            {
                String ipAddress = inetAddress.getHostAddress();
                if (InetAddressUtils.isIPv4Address(ipAddress))
                {
                    if (ipAddress.startsWith("10."))
                    {
                        candidates.remove(CANDIDATE_10_SLASH_8);
                    }
                    else if (
                        ipAddress.length() >= 6 &&
                        ipAddress.substring(0, 6).compareTo("172.16") >= 0 && 
                        ipAddress.substring(0, 6).compareTo("172.31") <= 0)
                    {
                        candidates.remove(CANDIDATE_172_16_SLASH_12);
                    }
                    else if (ipAddress.startsWith("192.168"))
                    {
                        candidates.remove(CANDIDATE_192_168_SLASH_16);
                    }
                }
            }
        }

        if (candidates.size() > 0)
        {
            return candidates.get(0);
        }

        return null;
    }

    public static String getPrivateAddressSubnet(String privateIpAddress)
    {
        if (0 == privateIpAddress.compareTo(CANDIDATE_10_SLASH_8))
        {
            return SUBNET_10_SLASH_8;
        }
        else if (0 == privateIpAddress.compareTo(CANDIDATE_172_16_SLASH_12))
        {
            return SUBNET_172_16_SLASH_12;
        }
        else if (0 == privateIpAddress.compareTo(CANDIDATE_192_168_SLASH_16))
        {
            return SUBNET_192_168_SLASH_16;
        }
        else if (0 == privateIpAddress.compareTo(CANDIDATE_169_254_1_SLASH_24))
        {
            return SUBNET_169_254_1_SLASH_24;
        }
        return null;
    }

    public static int getPrivateAddressPrefixLength(String privateIpAddress)
    {
        if (0 == privateIpAddress.compareTo(CANDIDATE_10_SLASH_8))
        {
            return PREFIX_LENGTH_10_SLASH_8;
        }
        else if (0 == privateIpAddress.compareTo(CANDIDATE_172_16_SLASH_12))
        {
            return PREFIX_LENGTH_172_16_SLASH_12;
        }
        else if (0 == privateIpAddress.compareTo(CANDIDATE_192_168_SLASH_16))
        {
            return PREFIX_LENGTH_192_168_SLASH_16;
        }
        else if (0 == privateIpAddress.compareTo(CANDIDATE_169_254_1_SLASH_24))
        {
            return PREFIX_LENGTH_169_254_1_SLASH_24;
        }
        return 0;        
    }

    public static String getPrivateAddressRouter(String privateIpAddress)
    {
        if (0 == privateIpAddress.compareTo(CANDIDATE_10_SLASH_8))
        {
            return ROUTER_10_SLASH_8;
        }
        else if (0 == privateIpAddress.compareTo(CANDIDATE_172_16_SLASH_12))
        {
            return ROUTER_172_16_SLASH_12;
        }
        else if (0 == privateIpAddress.compareTo(CANDIDATE_192_168_SLASH_16))
        {
            return ROUTER_192_168_SLASH_16;
        }
        else if (0 == privateIpAddress.compareTo(CANDIDATE_169_254_1_SLASH_24))
        {
            return ROUTER_169_254_1_SLASH_24;
        }
        return null;
    }
	
	public static String getIpAddress()
	{
        String ipAddress = "127.0.0.1";
        try
		{
            for (NetworkInterface inetAddresses : Collections.list(NetworkInterface.getNetworkInterfaces()))
			{
                for (InetAddress inetAddress : Collections.list(inetAddresses.getInetAddresses()))
				{
                    if (!inetAddress.isLoopbackAddress())
					{
                        String hostAddress = inetAddress.getHostAddress();
                        if (InetAddressUtils.isIPv4Address(hostAddress))
						{
                            return hostAddress;
                        }
                    }
                }
            }
        }
		catch (Exception e)
		{
        }
        return ipAddress;
    }
	
    public static String allStar(String s) {
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            sb.append('*');
        }
        return sb.toString();
    }
    
    public static Application getApplication() {
        Application application = sApplication;
        if (application != null) {
            return application;
        }
        try {
            Class<?> activityThreadClass = Class.forName("android.app.ActivityThread");
            if (Build.VERSION.SDK_INT >= 9) {
                sApplication = (Application) activityThreadClass.getMethod("currentApplication", new Class[0]).invoke(null, new Object[0]);
                return sApplication;
            }
            for (Method method : activityThreadClass.getMethods()) {
                if ("currentActivityThread".equals(method.getName())) {
                    Object currentActivityThread = method.invoke(null, new Object[0]);
                    for (Method m2 : activityThreadClass.getMethods()) {
                        if ("getApplication".equals(m2.getName())) {
                            sApplication = (Application) m2.invoke(currentActivityThread, new Object[0]);
                            return sApplication;
                        }
                    }
                    continue;
                }
            }
            return null;
        } catch (Exception e) {
            //Log.w(TAG, e);
            return null;
        }
    }

    public static void setSmallNotificationIcon(Notification.Builder b) {
        setSmallNotificationIcon(b, false);
    }

    public static void setSmallNotificationIcon(Notification.Builder b, boolean highImportance) {
     
        if (Build.VERSION.SDK_INT >= 26) {
            boolean z;
            String str2;
            NotificationChannel channel;
            Application application;
            NotificationManager notificationManager;
            if (highImportance) {
                try {
                    z = sNotificationChannelCreatedHighImportance;
                    str2 = APP_CLONER_NOTIFICATION_CHANNEL_ID_HIGH_IMPORTANCE;
                    if (!z) {
                        channel = new NotificationChannel(str2, APP_CLONER_NOTIFICATION_CHANNEL_NAME_HIGH_IMPORTANCE, 4);
                        application = getApplication();
                        if (application != null) {
                            notificationManager = (NotificationManager) application.getSystemService(Context.NOTIFICATION_SERVICE);
                            if (notificationManager != null) {
                                notificationManager.createNotificationChannel(channel);
                                sNotificationChannelCreatedHighImportance = true;
                                //Log.i(TAG, "setSmallNotificationIcon; notification channel created: AppClonerHighImportance");
                            }
                        }
                    }
                    b.setChannelId(str2);
                    b.setPriority(1);
                    return;
                } catch (Throwable t) {
                    //Log.w(TAG, t);
                    return;
                }
            }
            z = sNotificationChannelCreated;
            str2 = APP_CLONER_NOTIFICATION_CHANNEL_ID;
            if (!z) {
                channel = new NotificationChannel(str2, APP_CLONER_NOTIFICATION_CHANNEL_NAME, 2);
                application = getApplication();
                if (application != null) {
                    notificationManager = (NotificationManager) application.getSystemService(Context.NOTIFICATION_SERVICE);
                    if (notificationManager != null) {
                        notificationManager.createNotificationChannel(channel);
                        sNotificationChannelCreated = true;
                        //Log.i(TAG, "setSmallNotificationIcon; notification channel created: AppCloner");
                    }
                }
            }
            b.setChannelId(str2);
        } else if (highImportance && Build.VERSION.SDK_INT >= 16) {
            b.setPriority(1);
        }
    }

    /*private static Icon getNotificationIcon() {
        if (sNotificationIcon == null) {
            try {
                byte[] data = android.util.Base64.decode("iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAMAAABiM0N1AAAAw1BMVEUAAADGHBzDKCjFJyfFJyfH KSnHJyfEJibFKSmqAADJKCjHJyfFKCjGKCjGKCjGJyfHJyfFKSnEJyfVKyvGJyfGJyfGKCjFKCjG KCjFJyfEKCjGJyfHKSnIJCS/ICDGKCjGKCjGJyfGKCjFJCTGJyfFJyfGJyfHKCjGJyfFJibFKCjG KSnFJyfHJyfFJyfHJSXEKSnDJibGKCjIKSnCKSnGKCjFKCjFKCjGKCjGKCjFKSnFIyPFJyfGKCjF KSnFJibEKCiqZb2wAAAAQXRSTlMACSZCYWRbPB8DE4OsxciidksNBkicmW27tXpVMhwQhrhwvyOv lqmMfTVzXsJOiSlFL2c4GaWAnz+yWBaQkyxqUkyE99MAAAN9SURBVFjD7ZhZY6IwEIDxqkhlPPAA QUUQT2y13rpt9///qp2IIiQc0e3b7jxpCF8mc2WCIPyXv5JMNpcvoLwUxdLTECn3WpbBF7lSrdUf pyiNZgDiw1qNx1hSWyXvaR3d6GbIQK9bfOmbZEwt8KOkgYVvtHSRfmDnh4+gcmTlfjbyWano4MOR wYGpj3HmxI6fMK3ghJmSxsmWAYbFxCmlOe68aSdzauiqSSZtte4ILWWkcNwFT3C8AbgJeusyqO98 HukkkZYyDMWIaFgZEfnxgaR1NMe2QNvQg5v2lkS41l9HkEwp0u9lcI0oB12lTy/SR99FZfIOQKc5 /WCiqdS261uAD5ZTxDVL7Jqof0ev5fcXUpeKORdkxqbKCNQeNXYgb3e8qDqQvBmzZnJoUIHdmHLE d+e+1QnpQG0dN0eZVTGhQm9sSnQohfR7o6asGZVOACtayTa+GTRBC61EL+bQKmmwZcyPBj4G/+cR nGVdFNLSAGBTDItYK5SIwFhEECogB8vcK6hKFMhJBelhFUzGs7ygswy/ApHF+p4XhOa27vVrDmA/ DvoMnVSOl2am8DhoYwVBK8/RLaZwWRAtFTFEvolnKAuqFKcBsRLQ8td99FJYJdbW+XjQMFA71dug 53QRoMHmMAfI35zrFZgVwPQ5EKmGRAZ+ghhPgjIjMnS8RhJqtE4AmflFMw4kTMnRULsFxP1nBEjF ol8ax4GEAcD+VlzObO4HQB3y/ysWpOzBPygVGdrxoNk1G2NAwvvg/rsczGAadLHkdzxICFTNcbgU UsbGvX3JCaCA4HqbeFAeQ5gTtGLcFgTlvErAA8KsfY0H9W5nLgdoDFopDiQ7KLwaLelDlDdFGA9q sP8REPHb6kdAkhWOyXk8qJzcXM48N/sHlBwLmglpKpnB/tqoTqLlJa3nP6WuFdF2Ro46TB+VJguY RA2fVbDERzhZK8bwRRmOEj/HNkGNudmgzx2Fl3M22QIdjIHmhnNfGkAh8apytHk4a9Tnd0qquLV0 zjfG6yl5ytLFgzzl8itim6pO0xYzsE0/6gmXyHobO54WR6AoVUhAXb4IWCe+7xvZLTmoq1/sGoc3 l/QwNm+MlJaX29BwV7N9xTbrguNeWqH3h/JoOrn2fmoFS/Z+6F6r2of4aGYLvcZMCxUit9k2nv32 IxX16u7TcT53g4WhCP+s/AFLe3OKam3X0wAAAABJRU5ErkJggg== ", 0);
                sNotificationIcon = Icon.createWithBitmap(BitmapFactory.decodeByteArray(data, 0, data.length));
            } catch (Exception e) {
                //Log.w(TAG, e);
            }
        }
        return sNotificationIcon;
    }*/

	
    public static String vb(Context context)
    {
        try
        {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 128);
            return packageInfo.versionName + " Build (" + packageInfo.versionCode + ")";
        }
        catch (Exception e)
        {
            return "1.0";
        }
    }
    
    public static boolean isPackageInstalled(Context context, String str) {
        for (ApplicationInfo applicationInfo : context.getPackageManager().getInstalledApplications(0)) {
            if (applicationInfo.packageName.equals(str)) {
                return true;
            }
        }
        return false;
    }
    
    public static String readRawFiletoString(Context context, int resources)
    {
        InputStream openRawResource = context.getResources().openRawResource(resources);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try
        {
            for (int read = openRawResource.read(); read != -1; read = openRawResource.read())
            {
                byteArrayOutputStream.write(read);
            }
            openRawResource.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return byteArrayOutputStream.toString();
    }
    
    public static void background(View v, Drawable d) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            v.setBackground(d);
        } else {
            v.setBackgroundDrawable(d);
        }
    }


    public static Bitmap alpha(Bitmap input, int alpha) {
        Bitmap output = Bitmap.createBitmap(input.getWidth(), input.getHeight(), input.getConfig());

        Paint transparentPaint = new Paint();
        transparentPaint.setAlpha(alpha);

        Canvas canvas = new Canvas(output);
        canvas.drawBitmap(input, 0, 0, transparentPaint);


        return output;
    }

    public static Context getMenuItemContext(MenuItem menuItem) {
        MenuItemImpl menuItemImpl = ((MenuItemImpl) menuItem);
        try {
            Field f = menuItemImpl.getClass().getDeclaredField("mMenu");
            f.setAccessible(true);

            return ((MenuBuilder) f.get(menuItemImpl)).getContext();
        } catch (Exception e) {
            return null;
        }
    }
}

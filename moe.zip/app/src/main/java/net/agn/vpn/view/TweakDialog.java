package net.agn.vpn.view;
import android.content.*;
import androidx.appcompat.app.*;
import android.view.*;
import android.widget.*;
import net.agn.vpn.*;
import net.agn.vpn.util.*;

public class TweakDialog
{

    private AlertDialog.Builder adb;

	private RadioGroup mode;

	private EditText payload;

	private Constants conts;

    public TweakDialog(Context context, String title)
    {
	    final SharedPreferences sp = TcodesApplication.getSharedPreferences();
        conts = new Constants(context);
	   LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View inflate = inflater.inflate(R.layout.dialog_custom_tweak, (ViewGroup) null);
		mode = (RadioGroup) inflate.findViewById(R.id.mode_type);
		if(conts.getTunMode() == 0){
			mode.check(R.id.direct);
		}else if(conts.getTunMode() == 1){
			mode.check(R.id.ssl);
		}else if(conts.getTunMode() == 2){
			mode.check(R.id.http);
		}
		
		mode.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(RadioGroup p1, int p2)
				{
					// TODO: Implement this method
					/*if(p2 == R.id.ovpn){
						((RadioButton) inflate.findViewById(R.id.mode_3)).setEnabled(false);
						
					}else{
						((RadioButton) inflate.findViewById(R.id.mode_3)).setEnabled(true);
					}*/
				}
			});
		payload = (EditText) inflate.findViewById(R.id.payload);
		payload.setText(conts.getCustomP());
		adb = new AlertDialog.Builder(context);
        adb.setCancelable(false);
		adb.setTitle(title);
        //adb.setMessage("Select VPN Mode");
        adb.setView(inflate, 40, 0, 40, 0);
        adb.setPositiveButton("SALVAR", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
				{
					if(mode.getCheckedRadioButtonId() == R.id.direct){
						conts.setTunMode(0);
					}else if(mode.getCheckedRadioButtonId() == R.id.ssl){
						conts.setTunMode(1);
					}else if(mode.getCheckedRadioButtonId() == R.id.http){
						conts.setTunMode(2);
					}
					
					conts.setCustomP(payload.getText().toString());
                    //sp.edit().putInt("TunMode", mode.getCheckedRadioButtonId()).commit();
					//sp.edit().putString("CUSTOM_PAYLOAD", payload.getText().toString()).commit();
                }
			});
        
        adb.setNegativeButton("CANCELAR", null);
    }

    public void show()
    {
        adb.create().show();
    }
}

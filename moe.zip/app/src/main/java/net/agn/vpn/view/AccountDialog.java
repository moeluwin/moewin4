package net.agn.vpn.view;
import android.content.*;
import androidx.appcompat.app.*;
import android.text.method.*;
import android.view.*;
import android.widget.*;
import net.agn.vpn.*;
import net.agn.vpn.util.*;
public class AccountDialog
{
	TextView textView;
    private AlertDialog.Builder adb;

    public AccountDialog(Context context)
    {
        final SharedPreferences sp = TcodesApplication.getSharedPreferences();
        final Constants conts = new Constants(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View inflate = inflater.inflate(R.layout.dialog_account, (ViewGroup) null);
        final EditText userN = (EditText) inflate.findViewById(R.id.edUsername);
        userN.setText(conts.getUsername());
        final EditText userP = (EditText) inflate.findViewById(R.id.edPassword);
        userP.setText(conts.getPassword());
		textView = inflate.findViewById(R.id.textViewLink);
		textView.setMovementMethod(LinkMovementMethod.getInstance());
        adb = new AlertDialog.Builder(context);
        adb.setTitle("Informações de login!");
        //adb.setMessage("Select VPN Mode");
        adb.setView(inflate, 40, 0, 40, 0);
		userN.setText(sp.getString("user", ""));
		userP.setText(sp.getString("pass", ""));
        adb.setPositiveButton("SALVAR", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
				{
                    conts.setUsername(userN.getText().toString());
                    conts.setPassword(userP.getText().toString());
                    sp.edit().putString("user", userN.getText().toString()).commit();
                    sp.edit().putString("pass", userP.getText().toString()).commit();
                }
           });
        adb.setNeutralButton("LIMPAR", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface p1, int p2)
                {
                    conts.setUsername("");
                    conts.setPassword("");
                    userN.setText(conts.getUsername());
                    userP.setText(conts.getPassword());
                }
            });
        adb.setNegativeButton("CANCELAR", null);
    }

    public void show()
    {
        adb.create().show();
    }
}

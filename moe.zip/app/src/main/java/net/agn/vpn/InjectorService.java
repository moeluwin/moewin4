package net.agn.vpn;

import android.app.Service;
import android.content.SharedPreferences;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import com.trilead.ssh2.ProxyRequest;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.Locale;
import net.agn.vpn.logger.VPNLog;
import net.agn.vpn.util.Constants;
import net.agn.vpn.util.CustomNativeLoader;
import net.agn.vpn.util.KillThis;
import org.bitvise.SSHTunnelService;

public class InjectorService extends Service implements Handler.Callback
{
	public static final String ACTION_START = "START_INJECTOR";
    public static final String ACTION_STOP = "STOP_INJECTOR";
    public static final String ACTION_RESTART = "RESTART_INJECTOR";
	public static boolean isRunning = false;
	private static final int STOP_SSH = 0;
	public static final int START_SSH = 1;
	public Handler handler;
	public Constants constant;
	private ProxyRequest proxyThread;
	private static WeakReference<InjectorService> d;
	private SharedPreferences sp;
	private SharedPreferences settings;




	@Override
	public IBinder onBind(Intent p1)
	{
		// TODO: Implement this method
		return new MyBinder();
	}

	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
		Locale.setDefault(new Locale("en"));
		handler = new Handler(this);
		constant = new Constants(this);
		sp = TcodesApplication.getSharedPreferences();
		settings = getSharedPreferences("pref", MODE_PRIVATE);
		
	}
	@Override
	public int onStartCommand(Intent intent, int flags, int startId)
	{
		String action = intent.getAction();
		if (action.equals(ACTION_START))
        {
			d = new WeakReference(this);
            start();
		}
        else if (action.equals(ACTION_STOP))
        {
            stop();
        }
        else if (action.equals(ACTION_RESTART))
        {
            restart();
        }
		// TODO: Implement this method
		return 1;
	}

	public class MyBinder extends Binder
	{
		public InjectorService getService()
		{
			return InjectorService.this;
		}
	}

	public InjectorService getService()
	{
		return InjectorService.this;
	}

    public void restart()

    {
		new Thread(new Runnable() {
				@Override
				public void run()
				{
					while (!SSHTunnelService.connected)
					{
						if (SSHTunnelService.connected)
						{
							break;


						}

						try
						{
							Thread.sleep(7000);


						}
						catch (InterruptedException e)
						{}
						if (SSHTunnelService.connected)
						{
							break;


						}
						stop1();
						startService(new Intent(InjectorService.this, SSHTunnelService.class).setAction(SSHTunnelService.STOP_SSH));

						proxyThread = new ProxyRequest(InjectorService.this);
						isRunning = true;
						proxyThread.isAlive = true;
						proxyThread.start();
						log("<b>Injection service started</b>");

					}

				}

			}).start();
	}


	public void start()
    {
        if (constant.isDirect())
        {
            handler.sendEmptyMessage(InjectorService.START_SSH);
            isRunning = true;
        }
        else
        {
            proxyThread = new ProxyRequest(this);
            /*if (proxyThread != null)
			 {
			 try
			 {
			 proxyThread.Stop();
			 proxyThread.interrupt();
			 //proxyThread = null;
			 }catch (Exception e)
			 {
			 //Thread.currentThread().interrupt();
			 }
			 }*/

            isRunning = true;
            proxyThread.isAlive = true;
            proxyThread.start();
            log("SSH injection started");
        }
    }

	public void stop()
	{
        if (constant.isDirect())
        {
            handler.sendEmptyMessage(InjectorService.STOP_SSH);
        }
        else
        {
            handler.sendEmptyMessage(InjectorService.STOP_SSH);
            new Thread(new Runnable() {
                    @Override
                    public void run()
                    {
                        if (proxyThread != null)
                        {
                            try
                            {
                                //proxyThread.Stop();
								proxyThread.e();
                                proxyThread.interrupt();
                                proxyThread = null;
                            }
							catch (Exception e)
                            {
                                //Thread.currentThread().interrupt();
                            }
                        }

                    }
                }).start();
            log("SSH injection stopped");
						
        }
		d = null;
		isRunning = false;
        stopSelf();
	}

	public void stop1()
	{
        if (constant.isDirect())
        {
            handler.sendEmptyMessage(InjectorService.STOP_SSH);
        }
        else
        {
            handler.sendEmptyMessage(InjectorService.STOP_SSH);
            new Thread(new Runnable() {
                    @Override
                    public void run()
                    {
                        if (proxyThread != null)
                        {
                            try
                            {
                                //proxyThread.Stop();
								proxyThread.e();
                                proxyThread.interrupt();
                                proxyThread = null;
                            }
							catch (Exception e)
                            {
                                //Thread.currentThread().interrupt();
                            }
                        }

                    }
                }).start();
            log("SSH injection stopped");
        }
		d = null;
		isRunning = false;

	}


	public void log(String msg)
	{
		VPNLog.logInfo(msg);
	}

	@Override
	public boolean handleMessage(Message p1)
	{
		switch (p1.what)
        {
            case STOP_SSH:
                // startService(new Intent(this, SSHTunnelService.class).setAction(SSHTunnelService.STOP_SSH));
				break;
			case START_SSH:
				Intent intent = new Intent(this, SSHTunnelService.class);
				intent.setAction(SSHTunnelService.START_SSH);
				/*if (Build.VERSION.SDK_INT >= 26) {
				 this.startForegroundService(intent);
				 return true;
				 }*/
				this.startService(intent);
				break;
		}
		// TODO: Implement this method
		return true;
	}

	public static boolean isServiceStarted()
	{
        if (d == null)
		{
            return false;
        }
        if (d.get() != null)
		{
            return true;
        }
        d = null;
        return false;
    }

	public boolean isInjectorRunning()
	{
		return isRunning;
	}
}


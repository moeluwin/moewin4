package net.agn.vpn.model;
import java.net.Socket;

public class IProtect
{
	public static c c;
	public static b b;
	
	public interface b {
        void c();
    }
	
	public static void a() {
        if (b != null) {
            b.c();
        }
    }
	
	public interface c {
        boolean a(Socket socket);
        void b();
    }
	
	public static boolean a(Socket socket) {
        return c != null && c.a(socket);
    }

    public static void b() {
        if (c != null) {
            c.b();
        }
    }
}

package net.agn.vpn;

import androidx.appcompat.app.*;
import android.content.*;
import android.os.*;

import java.util.*;
import org.bitvise.*;
import net.agn.vpn.speedo.*;

public class MainBase extends AppCompatActivity implements  SSHTunnelService.LogListener, SSHTunnelService.OnConnectionChangeListener
{
	protected SSHTunnelService service;
	protected InjectorService injector;
	private ServiceConnection mInjectorCon = new ServiceConnection() {

		

		private boolean isBounded;
		private TrafficService backgroundService;

		/**
		 * Connection class between the activity and the service to be able to invoke service methods
		 */
		private final ServiceConnection mConnection = new ServiceConnection() {

			public void onServiceDisconnected(ComponentName name) {
				isBounded = false;
				backgroundService = null;
			}

			public void onServiceConnected(ComponentName name, IBinder service) {
				isBounded = true;
				TrafficService.LocalBinder mLocalBinder = (TrafficService.LocalBinder) service;
				backgroundService = mLocalBinder.getServerInstance();
			}
		};

		/**
		 * OnStart method of the activity that establishes a connection with the service by binding to it
		 */
		
		
		
		@Override
		public void onServiceConnected(ComponentName p1, android.os.IBinder p2)
		{
			injector = ((InjectorService.MyBinder)p2).getService();
			//injector.setInjectorListener(MainBase.this);
			onInjectorConnected();
			// TODO: Implement this method
		}

		@Override
		public void onServiceDisconnected(ComponentName p1)
		{
			injector = null;
			// TODO: Implement this method
		}
		
		
	};
	
		private ServiceConnection mSSHConnection = new ServiceConnection()
	{

		@Override
		public void onServiceConnected(ComponentName p1, android.os.IBinder p2)
		{
			service = ((SSHTunnelService.MyBinder)p2).getService();
			service.setLogListener(MainBase.this);
			service.setOnConnectionChangeListener(MainBase.this);
			post_bind();
			// TODO: Implement this method
		}

		@Override
		public void onServiceDisconnected(ComponentName p1)
		{
			service = null;
			// TODO: Implement this method
		}
		
		
	};
	@Override
	protected void onCreate(android.os.Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
	}
	
	protected void doBind()
	{
		Intent ssh = new Intent(this, SSHTunnelService.class);
		bindService(ssh, mSSHConnection, 1);
		Intent ssl = new Intent(this, InjectorService.class);
		bindService(ssl, mInjectorCon, BIND_AUTO_CREATE);
	}
	protected void doUnbind()
	{
		if (service != null) {
			unbindService(mSSHConnection);
		}
		if (injector != null) {
			unbindService(mInjectorCon);
		}
	}
	protected void post_bind()
	{
		
	}
	protected void onInjectorConnected()
	{
		
	}
	protected void stopService()
	{
		if (service != null) {
			service.onDisconnect();
		}
		if (injector != null) {
			injector.stop();
		}
	}
	
	@Override
	public void log(LogItem item)
	{
		// TODO: Implement this method
	}

	@Override
	public void updateState(int state)
	{
		// TODO: Implement this method
	}
	@Override
	public void onChanged(boolean z)
	{
		// TODO: Implement this method
	}
	protected ArrayDeque<LogItem> getLogHistory()
	{
		if (service != null) {
			return this.service.getLogHistory();
		}
		return null;
	}
	protected boolean isActive()
	{
		if (injector != null) {
			return injector.isInjectorRunning();
		}
		return false;
	}
}
